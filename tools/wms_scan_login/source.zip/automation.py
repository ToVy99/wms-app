"""Selenium-driven login. Does not bypass MFA, captchas or WMS policy."""
from __future__ import annotations

import re
import shutil
import tempfile
import time
from pathlib import Path
from typing import Callable

from selenium import webdriver
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait

from settings import decrypt_password


class AutomationError(Exception):
    pass


def _visible(elements):
    for element in elements:
        try:
            if element.is_displayed() and element.is_enabled():
                yield element
        except WebDriverException:
            pass


def _lookup(driver, css: str):
    if not css:
        return None
    try:
        return next(_visible(driver.find_elements(By.CSS_SELECTOR, css)), None)
    except WebDriverException:
        return None


def _detect_username(driver, custom_css: str):
    if custom_css:
        return _lookup(driver, custom_css)
    candidates = list(_visible(driver.find_elements(By.CSS_SELECTOR, "input:not([type='password'])")))
    text_candidates = []
    for element in candidates:
        eltype = (element.get_attribute("type") or "text").lower()
        if eltype not in ("text", "email", "tel", "number", "search", ""):
            continue
        descriptor = " ".join((element.get_attribute(attr) or "") for attr in (
            "name", "id", "placeholder", "aria-label", "autocomplete"
        )).lower()
        if re.search(r"user|account|login|email|employee|staff|tài khoản|nhân viên|đăng nhập|用户名|账号|帳號", descriptor):
            return element
        text_candidates.append(element)
    return text_candidates[0] if len(text_candidates) == 1 else None


def _detect_password(driver, custom_css: str):
    return _lookup(driver, custom_css or "input[type='password']")


def _detect_submit(driver, custom_css: str):
    if custom_css:
        return _lookup(driver, custom_css)
    candidates = list(_visible(driver.find_elements(By.CSS_SELECTOR, "button, input[type='submit'], [role='button']")))
    for element in candidates:
        name = " ".join(filter(None, [element.text, element.get_attribute("value") or "", element.get_attribute("aria-label") or ""]))
        if re.search(r"sign\s*in|log\s*in|login|đăng nhập|登录|登入|tiếp tục|continue", name, re.I):
            return element
    for element in candidates:
        if (element.get_attribute("type") or "").lower() == "submit":
            return element
    return candidates[0] if len(candidates) == 1 else None


def _goto_wms(driver, url: str, cfg: dict, status: Callable[[str], None]):
    driver.get(url)
    WebDriverWait(driver, 25).until(lambda browser: browser.execute_script("return document.readyState") == "complete")
    time.sleep(1)
    if _detect_password(driver, cfg.get("password_css", "")) is not None:
        return False
    if _detect_username(driver, cfg.get("username_css", "")) is not None:
        return False
    return "/v2/salesoutbound/" in driver.current_url


class SessionManager:
    """Keep CHECK/PACK in separate isolated Chrome profiles per employee scan."""
    def __init__(self):
        self.sessions = {}  # lane -> (driver, temp_profile_directory)

    def _close(self, lane: str):
        old = self.sessions.pop(lane, None)
        if old:
            driver, profile_dir = old
            try:
                driver.quit()
            except Exception:
                pass
            shutil.rmtree(profile_dir, ignore_errors=True)

    def close_all(self):
        for lane in list(self.sessions):
            self._close(lane)

    def login(self, lane: str, username: str, cfg: dict, status: Callable[[str], None]):
        if lane not in ("CHECK", "PACK"):
            raise AutomationError("Vị trí không hợp lệ.")
        password = decrypt_password(cfg.get("encrypted_password", ""))
        if not password:
            raise AutomationError("Chưa lưu mật khẩu. Vào Cài đặt để nhập mật khẩu chung.")
        if not username.strip():
            raise AutomationError("Mã tài khoản trống.")

        # Both lanes can coexist, but each scan starts a fresh browser profile.
        if not cfg.get("open_separate_windows", True):
            self.close_all()
        else:
            self._close(lane)
        profile = Path(tempfile.mkdtemp(prefix="wms_scan_"))
        options = webdriver.ChromeOptions()
        options.add_argument(f"--user-data-dir={profile}")
        options.add_argument("--start-maximized")
        options.add_argument("--no-first-run")
        options.add_argument("--no-default-browser-check")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        try:
            status(f"{lane}: Đang mở Chrome...")
            driver = webdriver.Chrome(options=options)
        except Exception as exc:
            shutil.rmtree(profile, ignore_errors=True)
            raise AutomationError("Không mở được Chrome. Kiểm tra Chrome và ChromeDriver/Selenium Manager.") from exc
        self.sessions[lane] = (driver, profile)
        target = cfg["check_url"] if lane == "CHECK" else cfg["pack_url"]
        try:
            status(f"{lane}: Đang tải WMS...")
            driver.get(cfg["login_url"])
            wait = WebDriverWait(driver, 30)
            wait.until(lambda d: _detect_username(d, cfg.get("username_css", "")) is not None or
                       _detect_password(d, cfg.get("password_css", "")) is not None or
                       "/v2/salesoutbound/" in d.current_url)
            username_box = _detect_username(driver, cfg.get("username_css", ""))
            password_box = _detect_password(driver, cfg.get("password_css", ""))
            if username_box is None:
                status(f"{lane}: Không tìm thấy ô tài khoản. Kiểm tra giao diện đăng nhập WMS.")
                raise AutomationError("Không xác định được ô tài khoản. Có thể cần chỉnh CSS Selector trong Cài đặt.")
            username_box.clear()
            username_box.send_keys(username.strip())

            # If a two-step username -> password form is used.
            if password_box is None:
                nxt = _detect_submit(driver, cfg.get("submit_css", ""))
                if nxt:
                    nxt.click()
                else:
                    username_box.send_keys(Keys.ENTER)
                try:
                    WebDriverWait(driver, 20).until(lambda d: _detect_password(d, cfg.get("password_css", "")) is not None)
                    password_box = _detect_password(driver, cfg.get("password_css", ""))
                except Exception:
                    raise AutomationError("Không tìm thấy ô mật khẩu sau khi nhập tài khoản.")
            if password_box is None:
                raise AutomationError("Không tìm thấy ô mật khẩu.")
            password_box.send_keys(password)
            submit = _detect_submit(driver, cfg.get("submit_css", ""))
            if submit:
                submit.click()
            else:
                password_box.send_keys(Keys.ENTER)

            status(f"{lane}: Đang chờ xác thực và mở trang đích...")
            # Wait for the password form to disappear or URL to change; never bypass additional authentication.
            try:
                WebDriverWait(driver, 30).until(lambda d:
                    _detect_password(d, cfg.get("password_css", "")) is None or
                    "/v2/salesoutbound/" in d.current_url)
            except Exception:
                raise AutomationError("Chưa xác nhận đăng nhập. Kiểm tra tài khoản/mật khẩu hoặc bước xác thực trên Chrome.")

            driver.get(target)
            try:
                WebDriverWait(driver, 30).until(lambda d:
                    target.split("?", 1)[0].rstrip("/") in d.current_url and
                    _detect_password(d, cfg.get("password_css", "")) is None)
            except Exception:
                raise AutomationError("Đã thử mở trang đích nhưng WMS chưa xác nhận phiên đăng nhập.")
            status(f"{lane}: Đã mở trang đích. Hãy kiểm tra tài khoản trên WMS.")
        except AutomationError:
            raise
        except WebDriverException as exc:
            raise AutomationError("Lỗi trình duyệt hoặc không truy cập được WMS: " + str(exc).splitlines()[0][:130]) from exc
