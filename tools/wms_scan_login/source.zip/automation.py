"""Selenium flow: scan -> Shopee WFM login -> CHECK/PACK tab.

Never bypasses account protection (OTP / CAPTCHA / SSO).  Password is not
included in this source and is decrypted locally with Windows DPAPI.
"""
from __future__ import annotations

import re
import shutil
import tempfile
from pathlib import Path
from typing import Callable
from urllib.parse import urlparse

from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait

from settings import decrypt_password

AUTH_HOST = "wfm.business.accounts.shopee.com"
WMS_HOST = "wms.ssc.shopee.vn"


class AutomationError(Exception):
    """An error message suitable for display to an operator."""


def _visible(elements):
    for element in elements:
        try:
            if element.is_displayed() and element.is_enabled():
                yield element
        except WebDriverException:
            continue


def _lookup(driver, css):
    if not css:
        return None
    return next(_visible(driver.find_elements(By.CSS_SELECTOR, css)), None)


def _detect_username(driver, custom_css=""):
    if custom_css:
        return _lookup(driver, custom_css)
    # WFM screenshot: placeholder="User ID".  Other selectors act as fallback.
    for css in (
        "input[placeholder*='User ID' i]",
        "input[placeholder*='Username' i]",
        "input[name='username']",
        "input[name='userId']",
        "input[autocomplete='username']",
        "input[id*='user' i]",
    ):
        match = _lookup(driver, css)
        if match is not None:
            return match
    candidates = list(_visible(driver.find_elements(By.CSS_SELECTOR, "input:not([type='password'])")))
    text_candidates = []
    for element in candidates:
        eltype = (element.get_attribute("type") or "text").lower()
        if eltype not in ("text", "email", "tel", "number", "search", ""):
            continue
        desc = " ".join((element.get_attribute(a) or "") for a in
                        ("name", "id", "placeholder", "aria-label", "autocomplete")).lower()
        if re.search(r"user|account|login|email|employee|staff|tài khoản|nhân viên|đăng nhập|用户名|账号", desc):
            return element
        text_candidates.append(element)
    return text_candidates[0] if len(text_candidates) == 1 else None


def _detect_password(driver, custom_css=""):
    return _lookup(driver, custom_css or "input[type='password']")


def _detect_submit(driver, custom_css=""):
    if custom_css:
        return _lookup(driver, custom_css)
    elements = list(_visible(driver.find_elements(By.CSS_SELECTOR, "button, input[type='submit'], [role='button']")))
    for element in elements:
        label = " ".join(filter(None, (element.text, element.get_attribute("value") or "",
                                       element.get_attribute("aria-label") or "")))
        if re.search(r"\blog\s*in\b|\bsign\s*in\b|đăng nhập|登录|登入", label, re.I):
            return element
    for element in elements:
        if (element.get_attribute("type") or "").lower() == "submit":
            return element
    return None


def _host(url):
    return (urlparse(url).hostname or "").lower()


def _auth_visible(driver, cfg):
    return _detect_password(driver, cfg.get("password_css", "")) is not None


def _login_loaded(driver, cfg):
    # Selenium follows the WMS -> WFM redirect. Do NOT treat the initial WMS
    # URL as proof that login has succeeded before the redirect completes.
    return _detect_username(driver, cfg.get("username_css", "")) is not None and \
        _detect_password(driver, cfg.get("password_css", "")) is not None


def _signed_in(driver, cfg):
    return _host(driver.current_url) == WMS_HOST and not _auth_visible(driver, cfg) and \
        driver.execute_script("return document.readyState") in ("interactive", "complete")


def _send_text(element, text):
    element.click()
    element.clear()
    element.send_keys(text)


def _explain_login_failure(driver, cfg):
    host = _host(driver.current_url)
    if host == AUTH_HOST or _auth_visible(driver, cfg):
        return ("Trang WFM vẫn đang hiển thị đăng nhập. Kiểm tra User ID/mật khẩu, "
                "thông báo lỗi hoặc bước xác thực trên Chrome.")
    return ("Không nhận được xác nhận đăng nhập từ WMS. "
            "Kiểm tra Chrome và kết nối mạng.")


class SessionManager:
    """Separate, isolated Chrome window/profile for each CHECK/PACK scan."""

    def __init__(self):
        self.sessions = {}  # CHECK/PACK -> (WebDriver, temporary profile directory)

    def _close(self, lane):
        old = self.sessions.pop(lane, None)
        if old:
            driver, profile = old
            try:
                driver.quit()
            except Exception:
                pass
            shutil.rmtree(profile, ignore_errors=True)

    def close_all(self):
        for lane in list(self.sessions):
            self._close(lane)

    def login(self, lane: str, username: str, cfg: dict, status: Callable[[str], None]):
        if lane not in ("CHECK", "PACK"):
            raise AutomationError("Vị trí không hợp lệ.")
        username = username.strip()
        if not username:
            raise AutomationError("Mã tài khoản trống.")
        try:
            password = decrypt_password(cfg.get("encrypted_password", ""))
        except Exception as exc:
            raise AutomationError("Không giải mã được mật khẩu đã lưu. Mở Cài đặt và nhập lại mật khẩu.") from exc
        if not password:
            raise AutomationError("Chưa lưu mật khẩu. Vào Cài đặt để nhập mật khẩu chung.")

        target = cfg["check_url"] if lane == "CHECK" else cfg["pack_url"]
        if not cfg.get("open_separate_windows", True):
            self.close_all()
        else:
            self._close(lane)
        profile = Path(tempfile.mkdtemp(prefix="wms_scan_"))
        options = webdriver.ChromeOptions()
        options.add_argument(f"--user-data-dir={profile}")
        options.add_argument("--start-maximized")
        options.add_argument("--no-first-run")
        options.add_argument("--no-default-browser-check")
        try:
            status(f"{lane}: Mở Chrome...")
            driver = webdriver.Chrome(options=options)
        except Exception as exc:
            shutil.rmtree(profile, ignore_errors=True)
            raise AutomationError("Không mở được Chrome. Kiểm tra Chrome đã cài và kết nối mạng.") from exc
        self.sessions[lane] = (driver, profile)
        try:
            status(f"{lane}: Mở trang WMS và chờ chuyển tới Shopee WFM...")
            driver.get(cfg["login_url"])
            try:
                WebDriverWait(driver, 50, poll_frequency=0.35).until(lambda d: _login_loaded(d, cfg))
            except TimeoutException as exc:
                raise AutomationError(
                    "Không thấy ô User ID/Password trên trang đăng nhập WFM sau 50 giây. "
                    "Kiểm tra trang đang mở trên Chrome."
                ) from exc

            username_input = _detect_username(driver, cfg.get("username_css", ""))
            password_input = _detect_password(driver, cfg.get("password_css", ""))
            if username_input is None or password_input is None:
                raise AutomationError("Không nhận diện được User ID hoặc Password trên WFM.")

            status(f"{lane}: Điền tài khoản và mật khẩu...")
            _send_text(username_input, username)
            _send_text(password_input, password)
            submit = _detect_submit(driver, cfg.get("submit_css", ""))
            if submit is None:
                password_input.send_keys(Keys.ENTER)
            else:
                WebDriverWait(driver, 12).until(lambda d: submit.is_enabled())
                submit.click()

            status(f"{lane}: Đã bấm Log In. Đang xác nhận phiên đăng nhập...")
            try:
                WebDriverWait(driver, 65, poll_frequency=0.5).until(lambda d: _signed_in(d, cfg))
            except TimeoutException as exc:
                raise AutomationError(_explain_login_failure(driver, cfg)) from exc

            # A new destination TAB appears after login. Close the old login
            # tab only after the target is confirmed, so operators see one
            # useful working tab rather than a stale authentication page.
            login_tab = driver.current_window_handle
            status(f"{lane}: Đã đăng nhập. Mở tab {lane}...")
            driver.switch_to.new_window("tab")
            driver.get(target)
            try:
                WebDriverWait(driver, 40, poll_frequency=0.5).until(
                    lambda d: d.current_url.split("?", 1)[0].rstrip("/") == target.split("?", 1)[0].rstrip("/")
                    and not _auth_visible(d, cfg)
                )
            except TimeoutException as exc:
                raise AutomationError(
                    "Đã đăng nhập nhưng không thể mở trang " + lane +
                    ". Kiểm tra quyền truy cập/kho đang chọn trên WMS."
                ) from exc
            # A login tab can usually be closed after the target tab is ready.
            try:
                new_tab = driver.current_window_handle
                driver.switch_to.window(login_tab)
                driver.close()
                driver.switch_to.window(new_tab)
            except WebDriverException:
                pass
            status(f"{lane}: Đăng nhập thành công và đã mở trang {lane}.")
        except AutomationError:
            raise
        except WebDriverException as exc:
            raise AutomationError(
                f"Chrome/Selenium: {exc.__class__.__name__}. "
                "Xem log lỗi để biết chi tiết."
            ) from exc
