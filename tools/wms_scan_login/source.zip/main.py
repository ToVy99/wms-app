"""WMS Scan Login GUI. Windows / Chrome / Selenium 4. No hard-coded passwords."""
from __future__ import annotations

import os
import traceback
from datetime import datetime
import queue
import threading
import tkinter as tk
from tkinter import messagebox, ttk

from settings import APP_DIR, DEFAULTS, encrypt_password, read_config, validate_wms_url, write_config


class WMSScanApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("WMS Scan Login | CHECK / PACK")
        self.root.geometry("800x450")
        self.root.minsize(680, 390)
        self.cfg = read_config()
        self.jobs: queue.Queue[tuple[str, str] | None] = queue.Queue()
        self.messages: queue.Queue[str] = queue.Queue()
        self.busy = False
        self.shutdown_started = False
        self.input_vars = {lane: tk.StringVar() for lane in ("CHECK", "PACK")}
        self.auto_after = {lane: None for lane in ("CHECK", "PACK")}
        self.scan_focus = "CHECK"
        self._build_ui()
        self.root.attributes("-topmost", bool(self.cfg["keep_on_top"]))
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(150, self._poll_messages)
        self.worker = threading.Thread(target=self._worker_loop, name="wms-browser-worker", daemon=True)
        self.worker.start()
        if not self.cfg.get("encrypted_password"):
            self.root.after(500, self._settings_dialog)
        self.entries["CHECK"].focus_set()

    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=18)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="WMS AUTO LOGIN", font=("Segoe UI", 19, "bold")).pack(anchor="w")
        ttk.Label(outer, text="Bấm vào ô CHECK hoặc PACK, sau đó quét mã nhân viên. Súng scan nên gửi Enter.",
                  wraplength=620).pack(anchor="w", pady=(4, 12))
        row = ttk.Frame(outer)
        row.pack(fill="both", expand=True)
        self.entries = {}
        self.buttons = {}
        for lane, label, dest in (("CHECK", "CHECK • Checking", "checkingnew"), ("PACK", "PACK • Packing", "packing")):
            box = ttk.LabelFrame(row, text=label, padding=14)
            box.pack(side="left", fill="both", expand=True, padx=(0, 7) if lane == "CHECK" else (7, 0))
            ttk.Label(box, text="Quét tài khoản:").pack(anchor="w")
            entry = ttk.Entry(box, textvariable=self.input_vars[lane], font=("Segoe UI", 17))
            entry.pack(fill="x", pady=(8, 8))
            entry.bind("<Return>", lambda event, l=lane: self._enqueue(l))
            entry.bind("<FocusIn>", lambda event, l=lane: setattr(self, "scan_focus", l))
            # Optional debounce for scanners that don't transmit Enter.
            # This is intentionally OFF to avoid submitting partial manual IDs.
            self.entries[lane] = entry
            button = ttk.Button(box, text=f"Đăng nhập {lane}", command=lambda l=lane: self._enqueue(l))
            button.pack(fill="x", ipady=8)
            self.buttons[lane] = button
            ttk.Label(box, text="Link đích đã lưu: " + dest, foreground="#555555").pack(anchor="w", pady=(10, 0))
        bottom = ttk.Frame(outer)
        bottom.pack(fill="x", pady=(14, 0))
        ttk.Button(bottom, text="⚙ Cài đặt", command=self._settings_dialog).pack(side="left")
        self.status = tk.StringVar(value="Sẵn sàng quét CHECK / PACK")
        ttk.Label(bottom, textvariable=self.status, wraplength=480).pack(side="left", padx=(12, 0))
        ttk.Label(outer, text="Quét mã + Enter: Chrome mở đăng nhập WFM rồi tự mở tab CHECK/PACK theo ô quét.",
                  foreground="#777777").pack(anchor="w", pady=(10, 0))

    def _enqueue(self, lane: str):
        if self.busy:
            self.status.set("Đang xử lý lượt quét trước. Vui lòng chờ.")
            return
        username = self.input_vars[lane].get().strip()
        if not username:
            self.entries[lane].focus_set()
            return
        if not self.cfg.get("encrypted_password"):
            messagebox.showwarning("Thiếu mật khẩu", "Hãy lưu mật khẩu dùng chung trong Cài đặt.")
            self._settings_dialog()
            return
        self.busy = True
        self.status.set(f"{lane}: Đang chuẩn bị đăng nhập...")
        self.buttons["CHECK"].configure(state="disabled")
        self.buttons["PACK"].configure(state="disabled")
        self.input_vars[lane].set("")
        self.jobs.put((lane, username))

    def _worker_loop(self):
        from automation import AutomationError, SessionManager
        manager = SessionManager()
        while True:
            job = self.jobs.get()
            if job is None:
                break
            lane, username = job
            try:
                manager.login(lane, username, self.cfg.copy(), self.messages.put)
            except AutomationError as exc:
                self.messages.put("LỖI: " + str(exc))
            except Exception as exc:
                # Write diagnostic details locally without including User ID or
                # the DPAPI-protected password in a shared/public repository.
                try:
                    APP_DIR.mkdir(parents=True, exist_ok=True)
                    detail = "\n".join(
                        f"{os.path.basename(frame.filename)}:{frame.lineno} ({frame.name})"
                        for frame in traceback.extract_tb(exc.__traceback__)
                    )
                    # Never write credentials, error strings or browser page HTML.
                    with (APP_DIR / "errors.log").open("a", encoding="utf-8") as log:
                        log.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] {lane}\n{detail}\n")
                except Exception:
                    pass
                self.messages.put(f"LỖI: {type(exc).__name__}. Xem %LOCALAPPDATA%\\WMS_Scan_Login\\errors.log")
            finally:
                self.messages.put("__DONE__")
        manager.close_all()

    def _poll_messages(self):
        try:
            while True:
                message = self.messages.get_nowait()
                if message == "__DONE__":
                    self.busy = False
                    for button in self.buttons.values():
                        button.configure(state="normal")
                else:
                    self.status.set(message)
        except queue.Empty:
            pass
        if not self.shutdown_started:
            self.root.after(150, self._poll_messages)

    def _settings_dialog(self):
        if self.busy:
            messagebox.showinfo("Đang đăng nhập", "Hãy đợi phiên hiện tại xử lý xong trước khi sửa cài đặt.")
            return
        win = tk.Toplevel(self.root)
        win.title("Cài đặt WMS Scan Login")
        win.geometry("740x515")
        win.transient(self.root)
        win.grab_set()
        panel = ttk.Frame(win, padding=16)
        panel.pack(fill="both", expand=True)
        fields = [
            ("login_url", "Trang WMS"),
            ("check_url", "Link CHECK"),
            ("pack_url", "Link PACK"),
            ("username_css", "CSS ô tài khoản (nâng cao, có thể bỏ trống)"),
            ("password_css", "CSS ô mật khẩu (nâng cao, có thể bỏ trống)"),
            ("submit_css", "CSS nút đăng nhập (nâng cao, có thể bỏ trống)"),
        ]
        variables = {}
        for key, title in fields:
            ttk.Label(panel, text=title).pack(anchor="w")
            var = tk.StringVar(value=self.cfg.get(key, ""))
            ttk.Entry(panel, textvariable=var).pack(fill="x", pady=(2, 7))
            variables[key] = var
        ttk.Label(panel, text="Mật khẩu dùng chung (để trống = giữ mật khẩu đã lưu)").pack(anchor="w")
        pwd_var = tk.StringVar()
        ttk.Entry(panel, textvariable=pwd_var, show="•").pack(fill="x", pady=(2, 8))
        separate = tk.BooleanVar(value=self.cfg["open_separate_windows"])
        on_top = tk.BooleanVar(value=self.cfg["keep_on_top"])
        ttk.Checkbutton(panel, text="Mở hai cửa sổ Chrome độc lập cho CHECK / PACK", variable=separate).pack(anchor="w")
        ttk.Checkbutton(panel, text="Giữ tool luôn ở trên cùng", variable=on_top).pack(anchor="w")

        def save():
            try:
                updated = self.cfg.copy()
                for key, var in variables.items():
                    updated[key] = (validate_wms_url(var.get()) if key.endswith("_url") else var.get().strip())
                updated["open_separate_windows"] = separate.get()
                updated["keep_on_top"] = on_top.get()
                if pwd_var.get():
                    updated["encrypted_password"] = encrypt_password(pwd_var.get())
                elif not updated.get("encrypted_password"):
                    raise ValueError("Bạn cần nhập mật khẩu dùng chung lần đầu.")
                write_config(updated)
                self.cfg = updated
                self.root.attributes("-topmost", updated["keep_on_top"])
                self.status.set("Đã lưu cài đặt. Sẵn sàng quét.")
                win.destroy()
            except Exception as exc:
                messagebox.showerror("Không lưu được", str(exc), parent=win)

        ttk.Button(panel, text="Lưu cài đặt", command=save).pack(anchor="e", pady=(12, 0))

    def _on_close(self):
        if self.shutdown_started:
            return
        self.shutdown_started = True
        self.status.set("Đang đóng phiên Chrome do tool quản lý...")
        self.jobs.put(None)
        self.root.after(150, self._finish_close)

    def _finish_close(self):
        if self.worker.is_alive():
            self.root.after(150, self._finish_close)
        else:
            self.root.destroy()


def main():
    if os.name != "nt":
        raise SystemExit("Ứng dụng dành cho Windows 10/11.")
    root = tk.Tk()
    WMSScanApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
