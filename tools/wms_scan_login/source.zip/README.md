# WMS Scan Login — CHECK / PACK (Windows)

Ứng dụng Windows dành cho máy quét barcode dạng bàn phím (USB/Bluetooth HID), đăng nhập bằng tài khoản vừa quét và chuyển tới đúng trang WMS.

- **CHECK:** `https://wms.ssc.shopee.vn/v2/salesoutbound/checkingnew`
- **PACK:** `https://wms.ssc.shopee.vn/v2/salesoutbound/packing`
- **Trang WMS:** `https://wms.ssc.shopee.vn/`
- Mật khẩu **KHÔNG có trong mã nguồn, ZIP hoặc EXE**. Nhập lần đầu trong Cài đặt. Có thể thay đổi về sau; ứng dụng sử dụng **Windows DPAPI** để mã hóa mật khẩu theo người dùng Windows hiện tại.

## Cách sử dụng
1. Dùng Windows 10/11 có Google Chrome, Python 3.11+ (nếu chạy mã nguồn).
2. Chạy `python -m pip install -r requirements.txt` rồi `python main.py`, hoặc dùng `WMS_Scan_Login.exe` nếu đã build.
3. Khi mở lần đầu, nhập **mật khẩu chung** trong **Cài đặt**, bấm Lưu. Các link được điền sẵn và sửa được.
4. Nhấn vào ô CHECK hoặc PACK, quét mã nhân viên. Súng nên cấu hình gửi **Enter** sau barcode. Hoặc bấm nút Đăng nhập.
5. Chờ Chrome đăng nhập và mở trang đích. Nếu có OTP / CAPTCHA / SSO hoặc WMS thay đổi biểu mẫu, thực hiện bước bắt buộc trực tiếp trên Chrome; tool không vượt qua những xác thực đó.
6. Quét mã mới vào đúng ô để đóng phiên Chrome cũ của vị trí tương ứng, mở phiên mới với hồ sơ Chrome sạch nhằm tránh dùng nhầm tài khoản.

## Build Windows EXE
- Trên Windows, chạy `BUILD_WINDOWS.bat` và lấy file `dist/WMS_Scan_Login.exe`.
- Hoặc đưa mã nguồn lên repo của bạn và chạy **GitHub Actions → Build WMS Scan Login Windows EXE → Run workflow**, tải artifact `WMS_Scan_Login_Windows`.
- Không thể tạo `.exe` Windows từ Linux chỉ với PyInstaller; phải chạy build ở Windows.
- ChromeDriver được Selenium Manager xử lý tự động. **Lần đầu có thể cần Internet** nếu driver chưa được tải/cached. Không cần dùng PowerShell để quản lý driver thủ công.

## Giới hạn, cách kiểm thử
- WMS là ứng dụng JavaScript có đăng nhập nội bộ. Chưa có quyền kiểm thử phiên đăng nhập thực tế, nên **chưa thể xác nhận 100% selector đăng nhập**. Nếu báo "Không xác định được ô tài khoản", mở Developer Tools (F12) trên trang login và xác định CSS selector. Ghi selector vào Cài đặt; hoặc cung cấp ảnh màn hình đăng nhập (che thông tin nhạy cảm) để tinh chỉnh.
- Khi tool đóng, các cửa sổ Chrome được tool quản lý cũng đóng. Khi nhiều người dùng chung máy, không để phiên đăng nhập cũ mở không giám sát.
- Không lưu lịch sử tài khoản và **không ghi log chứa mật khẩu**.
- Cần đảm bảo được phép dùng tự động hóa đăng nhập trong chính sách Shopee/WMS. Không bypass xác thực bổ sung.
- Mật khẩu mã hóa chỉ giải mã được trên tài khoản Windows đã lưu (thường không thể sao chép sang PC khác).
