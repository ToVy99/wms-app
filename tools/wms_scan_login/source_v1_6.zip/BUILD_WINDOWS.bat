@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  set PY=py -3
) else (
  set PY=python
)
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto :err
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name "WMS_Scan_Login" --collect-all selenium --collect-all trio --collect-all trio_websocket --collect-all websocket --collect-all urllib3 --collect-all certifi --collect-all sniffio --collect-all attrs main.py
if errorlevel 1 goto :err
echo.
echo DA BUILD XONG: dist\WMS_Scan_Login.exe
pause
exit /b 0
:err
echo BUILD THAT BAI. Vui long kiem tra Python va ket noi mang.
pause
exit /b 1
