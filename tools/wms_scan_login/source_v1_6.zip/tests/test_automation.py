"""Selector and page-state tests with stub elements (no WMS credentials/network)."""
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    from selenium.webdriver.common.by import By
    from automation import _detect_username, _detect_password, _detect_submit, _host, _login_loaded
except ModuleNotFoundError:
    By = None  # Python-only syntax check environment; GitHub Actions installs Selenium.


class Element:
    def __init__(self, attributes=None, text=""):
        self.attributes = attributes or {}
        self.text = text

    def is_displayed(self):
        return True

    def is_enabled(self):
        return True

    def get_attribute(self, key):
        return self.attributes.get(key)


class WFMPage:
    def __init__(self):
        self.user = Element({"type": "text", "placeholder": "User ID"})
        self.pwd = Element({"type": "password", "placeholder": "Password"})
        self.btn = Element({"type": "button"}, "Log In")

    def find_elements(self, by, css):
        assert by == By.CSS_SELECTOR
        if css in ("input[placeholder*='User ID' i]", "input:not([type='password'])"):
            return [self.user]
        if css == "input[type='password']":
            return [self.pwd]
        if css == "button, input[type='submit'], [role='button']":
            return [self.btn]
        return []


@unittest.skipIf(By is None, "Selenium not installed in local environment")
class LoginPageTests(unittest.TestCase):
    def test_user_id_password_submit_on_wfm(self):
        page = WFMPage()
        self.assertIs(_detect_username(page), page.user)
        self.assertIs(_detect_password(page), page.pwd)
        self.assertIs(_detect_submit(page), page.btn)
        self.assertTrue(_login_loaded(page, {}))

    def test_hosts(self):
        self.assertEqual(_host('https://wfm.business.accounts.shopee.com/authenticate/login'),
                         'wfm.business.accounts.shopee.com')
        self.assertEqual(_host('https://wms.ssc.shopee.vn/v2/salesoutbound/packing'),
                         'wms.ssc.shopee.vn')


if __name__ == '__main__':
    unittest.main()
