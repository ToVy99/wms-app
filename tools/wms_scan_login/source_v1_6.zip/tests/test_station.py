import unittest
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from settings import DEFAULTS, validate_station_id

class TestStationConfig(unittest.TestCase):
    def test_defaults(self):
        self.assertEqual(DEFAULTS["check_station_id"], "SS00085")
        self.assertEqual(DEFAULTS["pack_station_id"], "")
    def test_validation(self):
        self.assertEqual(validate_station_id(" ss00085 "), "SS00085")
        self.assertEqual(validate_station_id("  "), "")
        with self.assertRaises(ValueError):
            validate_station_id("SS 00085")
        with self.assertRaises(ValueError):
            validate_station_id("x" * 33)
