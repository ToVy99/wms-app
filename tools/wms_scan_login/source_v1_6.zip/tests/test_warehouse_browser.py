import os
import tempfile
import unittest
from urllib.parse import quote

try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from automation import _select_warehouse, _current_warehouse_control
    HAS_SELENIUM = True
except ImportError:
    HAS_SELENIUM = False


@unittest.skipUnless(HAS_SELENIUM, 'Requires Selenium')
class WarehouseBrowserTests(unittest.TestCase):
    def test_switch_from_sidebar_and_skip_when_correct(self):
        page = """<!DOCTYPE html><html><body>
            <aside style="position:absolute;left:10px;top:110px">
              <button id="warehouse" onclick="document.getElementById('options').style.display='block'">VN - VNA</button>
              <div id="options" style="display:none">
                <button id="option-vnn" onclick="document.getElementById('warehouse').textContent=this.textContent; document.getElementById('options').style.display='none'">VN - VNN</button>
              </div>
            </aside>
        </body></html>"""
        options = webdriver.ChromeOptions()
        options.add_argument('--headless=new')
        options.add_argument('--window-size=1200,780')
        with tempfile.TemporaryDirectory(prefix='warehouse-test-') as temp:
            options.add_argument('--user-data-dir=' + temp)
            browser = webdriver.Chrome(options=options)
            try:
                browser.get('data:text/html,' + quote(page))
                self.assertEqual(_current_warehouse_control(browser)[1], 'VN - VNA')
                messages = []
                self.assertTrue(_select_warehouse(browser, 'VN - VNN', messages.append, timeout=5))
                self.assertEqual(browser.find_element(By.ID, 'warehouse').text, 'VN - VNN')
                self.assertFalse(_select_warehouse(browser, 'VN - VNN', messages.append, timeout=5))
            finally:
                browser.quit()

if __name__ == '__main__':
    unittest.main()
