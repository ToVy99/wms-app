import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from settings import DEFAULTS, validate_warehouse

class WarehouseTests(unittest.TestCase):
    def test_safe_defaults(self):
        self.assertEqual(DEFAULTS['check_warehouse'], '')
        self.assertEqual(DEFAULTS['pack_warehouse'], '')
    def test_accept_known_and_custom_code(self):
        for value, expected in (('', ''), ('VN - VNA', 'VN - VNA'),
                                ('vn-vnn', 'VN - VNN'), (' VN  -   VNHN ', 'VN - VNHN')):
            self.assertEqual(validate_warehouse(value), expected)
    def test_reject_garbage(self):
        for value in ('VNA', 'Admin Portal', 'VN - VNA - XXX', 'https://other.com',
                      'VN - Region Dashboard', 'VN - VNA\nPACK'):
            with self.assertRaises(ValueError):
                validate_warehouse(value)

if __name__ == '__main__':
    unittest.main()
