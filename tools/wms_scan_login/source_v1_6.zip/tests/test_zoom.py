import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from settings import DEFAULTS, validate_zoom, ZOOM_PRESETS

class TestZoom(unittest.TestCase):
    def test_default(self):
        self.assertEqual(DEFAULTS["chrome_zoom_percent"], 75)
    def test_allowed(self):
        self.assertEqual(ZOOM_PRESETS, (50, 67, 75, 80, 90, 100))
        for value in ZOOM_PRESETS:
            self.assertEqual(validate_zoom(str(value) + "%"), value)
    def test_reject_invalid(self):
        for value in (0, 10, 74, 76, 101, 300, True, "-100", "bad"):
            with self.assertRaises(ValueError):
                validate_zoom(value)

if __name__ == "__main__":
    unittest.main()
