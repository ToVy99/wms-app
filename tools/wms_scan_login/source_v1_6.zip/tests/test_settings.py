import sys
from pathlib import Path
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from settings import DEFAULTS, validate_wms_url


class TestSettings(unittest.TestCase):
    def test_urls_default(self):
        self.assertEqual(DEFAULTS['check_url'].split('/')[-1], 'checkingnew')
        self.assertEqual(DEFAULTS['pack_url'].split('/')[-1], 'packing')

    def test_validate_allowed(self):
        self.assertEqual(validate_wms_url(DEFAULTS['check_url']), DEFAULTS['check_url'])

    def test_validate_prevent_other_host(self):
        for url in ('http://wms.ssc.shopee.vn/', 'https://wms.ssc.shopee.vn.evil.com/', 'https://other.com/'):
            with self.assertRaises(ValueError):
                validate_wms_url(url)


if __name__ == '__main__':
    unittest.main()
