"""App settings and Windows DPAPI-protected credential storage."""
from __future__ import annotations

import base64
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
from urllib.parse import urlparse

APP_DIR = Path(os.getenv("LOCALAPPDATA") or Path.home()) / "WMS_Scan_Login"
CONFIG_PATH = APP_DIR / "settings.json"
DEFAULTS = {
    "login_url": "https://wms.ssc.shopee.vn/",
    "check_url": "https://wms.ssc.shopee.vn/v2/salesoutbound/checkingnew",
    "pack_url": "https://wms.ssc.shopee.vn/v2/salesoutbound/packing",
    "open_separate_windows": True,
    "keep_on_top": False,
    "chrome_zoom_percent": 75,
    "check_station_id": "SS00085",
    "pack_station_id": "",
    "check_warehouse": "",
    "pack_warehouse": "",
    "username_css": "",
    "password_css": "",
    "submit_css": "",
    "encrypted_password": "",
}


class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _blob(raw: bytes):
    buffer = ctypes.create_string_buffer(raw)
    return DATA_BLOB(len(raw), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte))), buffer


def _dpapi(data: bytes, protect: bool) -> bytes:
    if os.name != "nt":
        raise RuntimeError("Chỉ hỗ trợ bảo vệ mật khẩu bằng Windows DPAPI.")
    in_blob, _in_buffer = _blob(data)
    out_blob = DATA_BLOB()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    func = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    func.argtypes = (
        [ctypes.POINTER(DATA_BLOB), wintypes.LPCWSTR, ctypes.POINTER(DATA_BLOB),
         ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(DATA_BLOB)]
        if protect else
        [ctypes.POINTER(DATA_BLOB), ctypes.POINTER(wintypes.LPWSTR), ctypes.POINTER(DATA_BLOB),
         ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(DATA_BLOB)]
    )
    func.restype = wintypes.BOOL
    success = func(ctypes.byref(in_blob), None, None, None, None, 0x1, ctypes.byref(out_blob))
    if not success:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree.argtypes = [ctypes.c_void_p]
        kernel32.LocalFree.restype = ctypes.c_void_p
        kernel32.LocalFree(out_blob.pbData)


def encrypt_password(password: str) -> str:
    return base64.b64encode(_dpapi(password.encode("utf-8"), True)).decode("ascii")


def decrypt_password(ciphertext: str) -> str:
    if not ciphertext:
        return ""
    return _dpapi(base64.b64decode(ciphertext), False).decode("utf-8")


def validate_station_id(value: str) -> str:
    """Blank disables station input. Nonblank is a scanner-compatible station code."""
    import re
    value = value.strip().upper()
    if value and not re.fullmatch(r"[A-Z0-9_-]{1,32}", value):
        raise ValueError("Mã trạm chỉ được chứa chữ A-Z, số, dấu - hoặc _, tối đa 32 ký tự.")
    return value


ZOOM_PRESETS = (50, 67, 75, 80, 90, 100)


def validate_zoom(value) -> int:
    """Only allow Chrome's common actual zoom steps, including full size."""
    if isinstance(value, bool):
        raise ValueError("Tỷ lệ thu phóng không hợp lệ.")
    try:
        val = int(str(value).strip().rstrip('%'))
    except (TypeError, ValueError) as exc:
        raise ValueError("Chọn tỷ lệ thu phóng từ 50% đến 100%.") from exc
    if val not in ZOOM_PRESETS:
        raise ValueError("Zoom chỉ hỗ trợ: 50%, 67%, 75%, 80%, 90%, 100%.")
    return val


def validate_warehouse(value: str) -> str:
    """Blank leaves the current WMS warehouse unchanged.

    Accepts authorized short warehouse IDs formatted VN - VNA, VN - VNN etc.
    Validation never grants the operator access to a warehouse.
    """
    import re
    text = re.sub(r"\s+", " ", str(value or "").strip()).upper()
    if not text:
        return ""
    match = re.fullmatch(r"VN\s*-\s*([A-Z0-9]{2,12})", text)
    if not match:
        raise ValueError("Kho phải có dạng VN - VNA, VN - VNN... hoặc để trống.")
    return "VN - " + match.group(1)


def read_config() -> dict:
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return DEFAULTS.copy()
        config = {**DEFAULTS, **{k: v for k, v in data.items() if k in DEFAULTS}}
        try:
            config["chrome_zoom_percent"] = validate_zoom(config.get("chrome_zoom_percent"))
        except ValueError:
            config["chrome_zoom_percent"] = 75
        for key in ("check_warehouse", "pack_warehouse"):
            try:
                config[key] = validate_warehouse(config.get(key, ""))
            except ValueError:
                config[key] = ""  # Invalid old config: never switch warehouses.
        return config
    except (FileNotFoundError, ValueError, OSError):
        return DEFAULTS.copy()


def write_config(data: dict) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    values = {key: data.get(key, default) for key, default in DEFAULTS.items()}
    values["chrome_zoom_percent"] = validate_zoom(values["chrome_zoom_percent"])
    for key in ("check_warehouse", "pack_warehouse"):
        values[key] = validate_warehouse(values[key])
    pending = CONFIG_PATH.with_suffix(".tmp")
    pending.write_text(json.dumps(values, ensure_ascii=False, indent=2), encoding="utf-8")
    pending.replace(CONFIG_PATH)


def validate_wms_url(url: str) -> str:
    """Only allow HTTPS links inside the configured WMS domain."""
    parsed = urlparse(url.strip())
    if parsed.scheme != "https" or parsed.hostname != "wms.ssc.shopee.vn":
        raise ValueError("Link phải bắt đầu bằng https://wms.ssc.shopee.vn/")
    if parsed.username or parsed.password or parsed.port or not url.strip():
        raise ValueError("Link WMS không hợp lệ.")
    return url.strip()
