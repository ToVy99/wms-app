"""WMS Scan Login v1.4 — modern Windows UI; scan workflow unchanged.

Pure Tkinter/ttk, no additional GUI dependencies. No passwords in source.
"""
from __future__ import annotations

import os
import sys
import traceback
from datetime import datetime
import queue
import threading
import tkinter as tk
from tkinter import messagebox, ttk

from settings import (APP_DIR, encrypt_password, read_config, validate_wms_url,
                      validate_station_id, validate_zoom, validate_warehouse, ZOOM_PRESETS, write_config)

BG = "#F3F6FB"
WHITE = "#FFFFFF"
NAVY = "#13253F"
TEXT = "#17263E"
MUTED = "#65748A"
BORDER = "#DFE7F1"
BLUE = "#2368E8"
PURPLE = "#7549D9"
SUCCESS = "#0C956B"
DANGER = "#C7434C"
FONT = "Segoe UI"


def label(parent, text, size=10, weight="normal", color=TEXT, bg=WHITE, **kw):
    return tk.Label(parent, text=text, font=(FONT, size, weight), fg=color, bg=bg, **kw)


def button(parent, text, command, bg, fg=WHITE, size=11, **kw):
    return tk.Button(parent, text=text, command=command, font=(FONT, size, "bold"),
                     bg=bg, fg=fg, activebackground=bg, activeforeground=fg,
                     relief="flat", bd=0, cursor="hand2", highlightthickness=0, **kw)


def line_entry(parent, variable, size=14, show=None, compact=False):
    edge = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
    entry = tk.Entry(edge, textvariable=variable, font=(FONT, size),
                     bg="#F8FAFD", fg=TEXT, insertbackground=TEXT,
                     relief="flat", bd=0, highlightthickness=0,
                     show=show or "")
    entry.pack(fill="x", ipady=3 if compact else 11, padx=12)
    entry.bind("<FocusIn>", lambda _e: edge.configure(bg=BLUE))
    entry.bind("<FocusOut>", lambda _e: edge.configure(bg=BORDER))
    return edge, entry


class WMSScanApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("WMS Scan Login  •  CHECK / PACK")
        self.root.geometry("940x650")
        self.root.minsize(760, 595)
        self.root.configure(bg=BG)
        # Native Tk window icon (no external image dependency).
        self._app_icon = tk.PhotoImage(width=32, height=32)
        self._app_icon.put("#13253F", to=(0, 0, 32, 32))
        for x, y in ((7, 7), (19, 7), (7, 19), (19, 19)):
            self._app_icon.put("#64D9E9", to=(x, y, x + 6, y + 6))
        self.root.iconphoto(True, self._app_icon)
        try:
            self.root.tk.call("tk", "scaling", max(1.0, min(root.winfo_fpixels("1i") / 72.0, 1.5)))
        except tk.TclError:
            pass
        self.cfg = read_config()
        self.jobs = queue.Queue()
        self.messages = queue.Queue()
        self.busy = False
        self.shutdown_started = False
        self.input_vars = {lane: tk.StringVar() for lane in ("CHECK", "PACK")}
        self.scan_focus = "CHECK"
        self._build_ui()
        self.root.attributes("-topmost", bool(self.cfg["keep_on_top"]))
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(150, self._poll_messages)
        self.worker = threading.Thread(target=self._worker_loop, name="wms-browser-worker", daemon=True)
        self.worker.start()
        if not self.cfg.get("encrypted_password") and not os.getenv("WMS_SCAN_UI_SMOKE"):
            self.root.after(400, self._settings_dialog)
        self.entries["CHECK"].focus_set()

    def _build_ui(self):
        header = tk.Frame(self.root, bg=NAVY, padx=26, pady=19)
        header.pack(fill="x")
        top = tk.Frame(header, bg=NAVY)
        top.pack(fill="x")
        mark = tk.Canvas(top, width=39, height=39, bg="#254362", highlightthickness=0)
        mark.create_rectangle(10, 10, 16, 16, fill="#64D9E9", outline="")
        mark.create_rectangle(22, 10, 28, 16, fill="#64D9E9", outline="")
        mark.create_rectangle(10, 22, 16, 28, fill="#64D9E9", outline="")
        mark.create_rectangle(22, 22, 28, 28, fill="#64D9E9", outline="")
        mark.pack(side="left", padx=(0, 13))
        title = tk.Frame(top, bg=NAVY)
        title.pack(side="left", fill="x", expand=True)
        label(title, "WMS  /  SCAN LOGIN", 10, "bold", "#9DB8D2", NAVY).pack(anchor="w")
        label(title, "Đăng nhập nhanh", 20, "bold", WHITE, NAVY).pack(anchor="w", pady=(1, 0))
        self.settings_button = button(top, "⚙  Cài đặt", self._settings_dialog, "#29415E", size=10, padx=17, pady=10)
        self.settings_button.pack(side="right")
        label(header, "Chọn vị trí làm việc, quét tài khoản và nhấn Enter. Chrome sẽ mở đúng trang WMS.",
              10, color="#C6D3E2", bg=NAVY).pack(anchor="w", pady=(12, 0))

        body = tk.Frame(self.root, bg=BG, padx=24, pady=20)
        body.pack(fill="both", expand=True)
        cards = tk.Frame(body, bg=BG)
        cards.pack(fill="both", expand=True)
        cards.grid_columnconfigure(0, weight=1, uniform="lane")
        cards.grid_columnconfigure(1, weight=1, uniform="lane")
        cards.grid_rowconfigure(0, weight=1)
        self.entries = {}
        self.buttons = {}
        self.station_labels = {}
        self.warehouse_labels = {}
        self._lane(cards, "CHECK", "Kiểm hàng", BLUE, 0)
        self._lane(cards, "PACK", "Đóng gói", PURPLE, 1)

        footer = tk.Frame(body, bg=BG)
        footer.pack(fill="x", pady=(17, 0))
        status_box = tk.Frame(footer, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        status_box.pack(fill="x")
        inset = tk.Frame(status_box, bg=WHITE, padx=16, pady=11)
        inset.pack(fill="both")
        self.status_dot = label(inset, "●", 12, color=SUCCESS)
        self.status_dot.pack(side="left", padx=(0, 10))
        self.status = tk.StringVar(value="Sẵn sàng quét tài khoản")
        self.status_text = label(inset, "", 10, color=TEXT, wraplength=790, justify="left")
        self.status_text.configure(textvariable=self.status)
        self.status_text.pack(side="left", fill="x", expand=True, anchor="w")
        label(body, "SÚNG SCAN: gửi Enter sau mã   •   Mã trạm được tự nhập nếu đã cài đặt", 9,
              color=MUTED, bg=BG).pack(anchor="w", pady=(8, 0))

    def _lane(self, parent, lane, caption, accent, column):
        outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
        outer.grid(row=0, column=column, sticky="nsew",
                   padx=(0, 9) if column == 0 else (9, 0))
        card = tk.Frame(outer, bg=WHITE)
        card.pack(fill="both", expand=True)
        tk.Frame(card, bg=accent, height=5).pack(fill="x")
        inside = tk.Frame(card, bg=WHITE, padx=21, pady=17)
        inside.pack(fill="both", expand=True)
        heading = tk.Frame(inside, bg=WHITE)
        heading.pack(fill="x")
        tile = tk.Frame(heading, bg="#E9F1FF" if lane == "CHECK" else "#F1EAFD", width=43, height=43)
        tile.pack(side="left")
        tile.pack_propagate(False)
        label(tile, "✓" if lane == "CHECK" else "▣", 19, "bold", accent,
              "#E9F1FF" if lane == "CHECK" else "#F1EAFD").pack(expand=True)
        heading_text = tk.Frame(heading, bg=WHITE)
        heading_text.pack(side="left", padx=12)
        label(heading_text, lane, 17, "bold").pack(anchor="w")
        label(heading_text, caption, 10, color=MUTED).pack(anchor="w")
        label(inside, "MÃ TÀI KHOẢN", 9, "bold", MUTED).pack(anchor="w", pady=(21, 7))
        entry_box, entry = line_entry(inside, self.input_vars[lane], size=16)
        entry_box.pack(fill="x")
        entry.bind("<Return>", lambda _event, which=lane: self._enqueue(which))
        entry.bind("<FocusIn>", lambda _event, which=lane: setattr(self, "scan_focus", which), add="+")
        self.entries[lane] = entry
        action = button(inside, f"Đăng nhập {lane}   →", lambda which=lane: self._enqueue(which),
                        accent, size=11, pady=12)
        action.pack(fill="x", pady=(14, 0))
        self.buttons[lane] = action
        note = tk.Frame(inside, bg=WHITE)
        note.pack(side="bottom", fill="x", pady=(18, 0))
        tk.Frame(note, bg=BORDER, height=1).pack(fill="x", pady=(0, 12))
        label(note, "TRANG ĐÍCH", 9, "bold", MUTED).pack(anchor="w")
        label(note, "Sales Outbound  /  " + ("Checking" if lane == "CHECK" else "Packing"),
              10, color=TEXT).pack(anchor="w", pady=(2, 8))
        station = label(note, "", 9, "bold", accent)
        station.pack(anchor="w")
        self.station_labels[lane] = station
        warehouse_info = label(note, "", 9, color=MUTED)
        warehouse_info.pack(anchor="w", pady=(2, 0))
        self.warehouse_labels[lane] = warehouse_info
        self._refresh_station(lane)
        self._refresh_warehouse(lane)

    def _refresh_station(self, lane):
        station = self.cfg.get("check_station_id" if lane == "CHECK" else "pack_station_id", "")
        self.station_labels[lane].configure(
            text=f"●  Trạm {station}  ·  Tự nhập + Enter" if station else "○  Không tự nhập mã trạm")

    def _refresh_warehouse(self, lane):
        value = self.cfg.get("check_warehouse" if lane == "CHECK" else "pack_warehouse", "")
        self.warehouse_labels[lane].configure(
            text=f"Kho mặc định: {value}" if value else "Kho: giữ theo WMS"
        )

    def _set_status(self, message):
        self.status.set(message)
        color = DANGER if message.startswith("LỖI") or "nhưng chưa" in message else (
            SUCCESS if "thành công" in message.lower() or "Đã lưu" in message else (
                BLUE if self.busy else SUCCESS))
        self.status_dot.configure(fg=color)

    def _enqueue(self, lane):
        if self.busy:
            self._set_status("Đang xử lý lượt quét trước. Vui lòng chờ.")
            return
        username = self.input_vars[lane].get().strip()
        if not username:
            self.entries[lane].focus_set()
            return
        if not self.cfg.get("encrypted_password"):
            messagebox.showwarning("Thiếu mật khẩu", "Nhập mật khẩu dùng chung trong Cài đặt.")
            self._settings_dialog()
            return
        self.busy = True
        self._set_status(f"{lane}: Đang mở Chrome và đăng nhập...")
        for item in self.buttons.values():
            item.configure(state="disabled")
        self.input_vars[lane].set("")
        self.jobs.put((lane, username))

    def _worker_loop(self):
        try:
            from automation import AutomationError, SessionManager
            manager = SessionManager()
        except Exception as exc:
            self.messages.put(f"LỖI: Không khởi tạo được Selenium ({type(exc).__name__}).")
            return
        while True:
            job = self.jobs.get()
            if job is None:
                break
            lane, username = job
            try:
                manager.login(lane, username, self.cfg.copy(), self.messages.put)
            except AutomationError as exc:
                self.messages.put("LỖI: " + str(exc))
            except Exception as exc:
                try:
                    APP_DIR.mkdir(parents=True, exist_ok=True)
                    detail = "\n".join(f"{os.path.basename(f.filename)}:{f.lineno} ({f.name})"
                                       for f in traceback.extract_tb(exc.__traceback__))
                    with (APP_DIR / "errors.log").open("a", encoding="utf-8") as log:
                        log.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] {lane} {type(exc).__name__}\n{detail}\n")
                except Exception:
                    pass
                hint = f" - thiếu {exc.name}" if isinstance(exc, ModuleNotFoundError) else ""
                self.messages.put(f"LỖI: {type(exc).__name__}{hint}. Xem errors.log trong %LOCALAPPDATA%\\WMS_Scan_Login")
            finally:
                self.messages.put("__DONE__")
        manager.close_all()

    def _poll_messages(self):
        try:
            while True:
                message = self.messages.get_nowait()
                if message == "__DONE__":
                    self.busy = False
                    for item in self.buttons.values():
                        item.configure(state="normal")
                else:
                    self._set_status(message)
        except queue.Empty:
            pass
        if not self.shutdown_started:
            self.root.after(150, self._poll_messages)

    def _settings_dialog(self):
        if self.busy:
            messagebox.showinfo("Đang đăng nhập", "Đợi lượt hiện tại hoàn thành trước khi sửa Cài đặt.")
            return
        if getattr(self, "settings_win", None) and self.settings_win.winfo_exists():
            self.settings_win.lift()
            return
        win = tk.Toplevel(self.root)
        self.settings_win = win
        win.title("Cài đặt • WMS Scan Login")
        win.configure(bg=BG)
        win.geometry("750x690")
        win.minsize(650, 615)
        win.transient(self.root)
        win.grab_set()
        head = tk.Frame(win, bg=NAVY, padx=23, pady=17)
        head.pack(fill="x")
        label(head, "CÀI ĐẶT", 17, "bold", WHITE, NAVY).pack(anchor="w")
        label(head, "Thiết lập tài khoản, mã trạm và đường dẫn WMS", 10,
              color="#C6D3E2", bg=NAVY).pack(anchor="w", pady=(3, 0))
        tabs = tk.Frame(win, bg=BG, padx=20, pady=13)
        tabs.pack(fill="x")
        panel = tk.Frame(win, bg=WHITE, padx=23, pady=17)
        panel.pack(fill="both", expand=True, padx=20)
        basic = tk.Frame(panel, bg=WHITE)
        advanced = tk.Frame(panel, bg=WHITE)
        warehouses = tk.Frame(panel, bg=WHITE)
        vars_ = {}

        def field(host, name, key, default="", secret=False, size=11, compact=False):
            label(host, name, 10, "bold", MUTED).pack(anchor="w", pady=(0, 3 if compact else 5))
            var = tk.StringVar(value=default)
            edge, widget = line_entry(host, var, size=size, show="●" if secret else None, compact=compact)
            widget.configure(font=(FONT, size))
            edge.pack(fill="x", pady=(0, 4 if compact else 13))
            vars_[key] = var
            return widget

        label(basic, "MẬT KHẨU CHUNG", 10, "bold", TEXT).pack(anchor="w", pady=(0, 8))
        password_entry = field(basic, "Nhập mật khẩu mới (để trống = giữ mật khẩu đã lưu)", "new_password", secret=True)
        show_pwd = tk.BooleanVar(value=False)
        tk.Checkbutton(basic, text="Hiện mật khẩu", variable=show_pwd, bg=WHITE, fg=MUTED,
                       font=(FONT, 9), relief="flat", activebackground=WHITE,
                       command=lambda: password_entry.configure(show="" if show_pwd.get() else "●")
                       ).pack(anchor="w", pady=(0, 14))
        label(basic, "TỰ NHẬP MÃ TRẠM", 10, "bold", TEXT).pack(anchor="w", pady=(0, 7))
        station_grid = tk.Frame(basic, bg=WHITE)
        station_grid.pack(fill="x")
        for col, (lane, key) in enumerate((("CHECK", "check_station_id"), ("PACK", "pack_station_id"))):
            cell = tk.Frame(station_grid, bg=WHITE)
            cell.grid(row=0, column=col, sticky="ew", padx=(0, 12) if col == 0 else (12, 0))
            station_grid.grid_columnconfigure(col, weight=1)
            field(cell, f"Mã trạm {lane}", key, self.cfg.get(key, ""))
        label(basic, "Để trống sẽ không tự nhập. Có mã → tự nhập và nhấn Enter.", 9,
              color=MUTED).pack(anchor="w", pady=(0, 11))
        zoom_row = tk.Frame(basic, bg=WHITE)
        zoom_row.pack(fill="x", pady=(1, 7))
        zoom_copy = tk.Frame(zoom_row, bg=WHITE)
        zoom_copy.pack(side="left", fill="x", expand=True)
        label(zoom_copy, "ZOOM TRANG WMS", 10, "bold", TEXT).pack(anchor="w")
        label(zoom_copy, "Thu nhỏ sau mã trạm + Enter khoảng 5 giây", 9, color=MUTED).pack(anchor="w")
        zoom_var = tk.StringVar(value=f"{self.cfg.get('chrome_zoom_percent', 75)}%")
        self.zoom_selector = ttk.Combobox(
            zoom_row, textvariable=zoom_var, values=[f"{n}%" for n in ZOOM_PRESETS],
            state="readonly", width=8, font=(FONT, 11), justify="center")
        self.zoom_selector.pack(side="right", ipady=5, padx=(10, 0))
        self.zoom_selector.state(["readonly"])
        label(basic, "TÙY CHỌN", 10, "bold", TEXT).pack(anchor="w", pady=(2, 8))
        separate = tk.BooleanVar(value=self.cfg["open_separate_windows"])
        on_top = tk.BooleanVar(value=self.cfg["keep_on_top"])
        for text, var in (("Mỗi vị trí CHECK / PACK dùng một cửa sổ Chrome riêng", separate),
                          ("Giữ cửa sổ tool luôn ở trên cùng", on_top)):
            tk.Checkbutton(basic, text=text, variable=var, bg=WHITE, fg=TEXT,
                           font=(FONT, 10), relief="flat", activebackground=WHITE,
                           anchor="w").pack(fill="x", pady=2)
        label(advanced, "ĐƯỜNG DẪN WMS", 10, "bold", TEXT).pack(anchor="w", pady=(0, 12))
        for key, title in (("login_url", "Trang đăng nhập WMS"),
                           ("check_url", "Link trang CHECK"),
                           ("pack_url", "Link trang PACK")):
            field(advanced, title, key, self.cfg.get(key, ""), size=10, compact=True)
        label(advanced, "CSS SELECTOR NÂNG CAO", 10, "bold", TEXT).pack(anchor="w", pady=(2, 12))
        for key, title in (("username_css", "Ô tài khoản"),
                           ("password_css", "Ô mật khẩu"),
                           ("submit_css", "Nút Log In")):
            field(advanced, title, key, self.cfg.get(key, ""), size=10, compact=True)

        label(warehouses, "KHO MẶC ĐỊNH THEO VỊ TRÍ", 11, "bold", TEXT).pack(anchor="w", pady=(0, 12))
        label(warehouses,
              "Sau khi đăng nhập, tool chọn kho đúng trước khi nhập mã trạm.",
              10, color=MUTED).pack(anchor="w", pady=(0, 16))
        warehouse_vars = {}
        for lane, key in (("CHECK", "check_warehouse"), ("PACK", "pack_warehouse")):
            label(warehouses, f"Kho cho {lane}  (để trống = không đổi kho)",
                  10, "bold", MUTED).pack(anchor="w", pady=(0, 5))
            var = tk.StringVar(value=self.cfg.get(key, ""))
            selector = ttk.Combobox(
                warehouses, textvariable=var, font=(FONT, 11), state="normal",
                values=("", "VN - VNA", "VN - VNG", "VN - VNHN", "VN - VNN"),
            )
            selector.pack(fill="x", ipady=5, pady=(0, 18))
            warehouse_vars[key] = var
        label(warehouses,
              "Chỉ chọn kho có trong danh sách WMS của tài khoản.\n"
              "Không tìm thấy hoặc chưa xác nhận chuyển kho → không tự quét trạm.",
              10, color=MUTED, justify="left").pack(anchor="w", pady=(6, 0))

        tab_buttons = {}
        def select_tab(which):
            for frame in (basic, advanced, warehouses):
                frame.pack_forget()
            (basic if which == "basic" else advanced if which == "advanced" else warehouses).pack(fill="both", expand=True)
            for key, tab in tab_buttons.items():
                tab.configure(bg=NAVY if key == which else WHITE,
                              fg=WHITE if key == which else TEXT)

        for key, title in (("basic", "Cơ bản"), ("warehouse", "Kho làm việc"), ("advanced", "Nâng cao")):
            b = button(tabs, title, lambda key=key: select_tab(key), WHITE, TEXT,
                       size=10, padx=19, pady=9)
            b.pack(side="left", padx=(0, 9))
            tab_buttons[key] = b
        select_tab("basic")

        foot = tk.Frame(win, bg=BG, padx=20, pady=12)
        foot.pack(side="bottom", fill="x", before=panel)
        button(foot, "Huỷ", win.destroy, WHITE, TEXT, size=10,
               padx=21, pady=11).pack(side="right", padx=(10, 0))

        def save():
            try:
                new = self.cfg.copy()
                for key, var in vars_.items():
                    if key == "new_password":
                        if var.get():
                            new["encrypted_password"] = encrypt_password(var.get())
                    elif key.endswith("_station_id"):
                        new[key] = validate_station_id(var.get())
                    elif key.endswith("_url"):
                        new[key] = validate_wms_url(var.get())
                    else:
                        new[key] = var.get().strip()
                if not new.get("encrypted_password"):
                    raise ValueError("Nhập mật khẩu dùng chung trước khi lưu.")
                new["chrome_zoom_percent"] = validate_zoom(zoom_var.get())
                for key, var in warehouse_vars.items():
                    new[key] = validate_warehouse(var.get())
                new["open_separate_windows"] = separate.get()
                new["keep_on_top"] = on_top.get()
                write_config(new)
                self.cfg = new
                self.root.attributes("-topmost", new["keep_on_top"])
                for lane in ("CHECK", "PACK"):
                    self._refresh_station(lane)
                    self._refresh_warehouse(lane)
                self._set_status("Đã lưu cài đặt. Sẵn sàng quét.")
                win.destroy()
            except Exception as exc:
                messagebox.showerror("Không lưu được", str(exc), parent=win)

        button(foot, "Lưu cài đặt   ✓", save, BLUE, size=10,
               padx=22, pady=11).pack(side="right")

    def _on_close(self):
        if self.shutdown_started:
            return
        self.shutdown_started = True
        self._set_status("Đang đóng các phiên Chrome do tool quản lý...")
        self.jobs.put(None)
        self.root.after(150, self._finish_close)

    def _finish_close(self):
        if self.worker.is_alive():
            self.root.after(150, self._finish_close)
        else:
            self.root.destroy()


def _self_test():
    """Integration smoke test on local synthetic HTML, never live WMS."""
    from pathlib import Path
    import tempfile
    from urllib.parse import quote
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from automation import _host, _enter_station, _set_browser_zoom

    result = Path.cwd() / "wms_scan_smoke_result.txt"
    driver = None
    try:
        assert _host("https://wms.business.accounts.shopee.com/authenticate/login") == \
            "wms.business.accounts.shopee.com"
        opts = webdriver.ChromeOptions()
        opts.add_argument("--headless=new")
        opts.add_argument("--no-first-run")
        with tempfile.TemporaryDirectory(prefix="wms_smoke_") as folder:
            opts.add_argument(f"--user-data-dir={folder}")
            driver = webdriver.Chrome(options=opts)
            driver.get("data:text/html,<title>WMS smoke test</title>")
            assert driver.title == "WMS smoke test"
            html = ("<html><input id='station' placeholder='Station ID'>"
                    "<b id='received'></b><script>"
                    "document.getElementById('station').addEventListener('keydown',"
                    "function(e){if(e.key==='Enter')"
                    "document.getElementById('received').textContent=this.value;});"
                    "</script></html>")
            driver.get("data:text/html," + quote(html))
            _enter_station(driver, "SS00085", lambda _status: None)
            assert driver.find_element(By.ID, "received").text == "SS00085"
            # Verify zoom on the frozen Windows EXE, not just Python modules.
            baseline_dpr = float(driver.execute_script("return window.devicePixelRatio") or 1)
            assert _set_browser_zoom(driver, 75, lambda _status: None)
            css_zoom = driver.execute_script("return document.documentElement.style.zoom")
            chrome_dpr = float(driver.execute_script("return window.devicePixelRatio") or 1)
            assert css_zoom in ("75%", "0.75") or abs(chrome_dpr / baseline_dpr - 0.75) < 0.055, (css_zoom, chrome_dpr, baseline_dpr)
            driver.quit()
            driver = None
        result.write_text("PASS: Selenium, Chrome, station input and Enter.\n", encoding="utf-8")
        return 0
    except Exception as exc:
        result.write_text(f"FAIL: {type(exc).__name__}: {str(exc)[:300]}\n", encoding="utf-8")
        return 1
    finally:
        if driver:
            try:
                driver.quit()
            except Exception:
                pass


def _ui_smoke():
    """Verify both scanner entry widgets and the settings dialog can open."""
    from pathlib import Path
    try:
        os.environ["WMS_SCAN_UI_SMOKE"] = "1"
        root = tk.Tk()
        app = WMSScanApp(root)
        root.update()
        assert all(app.entries[l].winfo_exists() for l in ("CHECK", "PACK"))
        app._settings_dialog()
        root.update()
        assert app.settings_win.winfo_exists()
        assert app.zoom_selector.instate(["readonly"])
        assert "75%" in app.zoom_selector.cget("values")
        assert all(app.warehouse_labels[lane].winfo_exists() for lane in ("CHECK", "PACK"))
        app.settings_win.destroy()
        root.destroy()
        (Path.cwd() / "wms_ui_smoke_result.txt").write_text("PASS: GUI and settings dialog.\n", encoding="utf-8")
        return 0
    except Exception as exc:
        (Path.cwd() / "wms_ui_smoke_result.txt").write_text(f"FAIL: {type(exc).__name__}: {exc}\n", encoding="utf-8")
        return 1


def main():
    if os.name != "nt":
        raise SystemExit("Ứng dụng dành cho Windows 10/11.")
    root = tk.Tk()
    WMSScanApp(root)
    root.mainloop()


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        sys.exit(_self_test())
    if "--ui-smoke" in sys.argv:
        sys.exit(_ui_smoke())
    main()
