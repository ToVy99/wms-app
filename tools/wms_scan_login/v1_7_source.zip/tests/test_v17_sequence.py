"""v1.7 regression tests: no-warehouse fast path and warehouse reload order."""
import sys
import unittest
from pathlib import Path
from unittest.mock import patch, Mock
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from settings import DEFAULTS
import automation as m


class FlowTests(unittest.TestCase):
    def setUp(self):
        self.cfg = {**DEFAULTS, "check_station_id": "SS00085"}
        self.driver = Mock()
        self.events = []
        self.target = DEFAULTS['check_url']

    def test_without_warehouse_does_not_switch_or_reload(self):
        self.cfg['check_warehouse'] = ''
        with patch.object(m, '_select_warehouse', side_effect=AssertionError('must not switch')), \
             patch.object(m, '_wait_warehouse_reload', side_effect=AssertionError('must not reload')), \
             patch.object(m, '_wait_work_page', return_value='station') as ready, \
             patch.object(m, '_enter_station', side_effect=lambda *_: self.events.append('station')), \
             patch.object(m, '_finalize_after_station', side_effect=lambda *_a, **_kw: self.events.append('zoom') or True):
            m._complete_workflow(self.driver, 'CHECK', self.cfg, self.target, self.events.append)
            ready.assert_called_once()
        self.driver.get.assert_not_called()
        self.assertEqual(self.events.count('station'), 1)
        self.assertEqual(self.events.count('zoom'), 1)

    def test_warehouse_changed_must_stabilize_before_navigation_or_scan(self):
        self.cfg['check_warehouse'] = 'VN - VNN'
        order=[]
        self.driver.get.side_effect=lambda _url: order.append('navigate')
        with patch.object(m, '_select_warehouse', side_effect=lambda *_a, **_kw: order.append('select') or True), \
             patch.object(m, '_wait_warehouse_reload', side_effect=lambda *_a, **_kw: order.append('warehouse-ready')), \
             patch.object(m, '_wait_work_page', side_effect=lambda *_a, **_kw: order.append('scanner-ready') or 'station'), \
             patch.object(m, '_enter_station', side_effect=lambda *_a, **_kw: order.append('station')), \
             patch.object(m, '_finalize_after_station', side_effect=lambda *_a, **_kw: order.append('zoom') or True):
            m._complete_workflow(self.driver, 'CHECK', self.cfg, self.target, self.events.append)
        self.assertEqual(order, ['select','warehouse-ready','navigate','scanner-ready','station','zoom'])

    def test_existing_warehouse_does_not_reopen_tab(self):
        self.cfg['check_warehouse'] = 'VN - VNA'
        with patch.object(m, '_select_warehouse', return_value=False), \
             patch.object(m, '_wait_warehouse_reload', side_effect=AssertionError('not switched')), \
             patch.object(m, '_wait_work_page', return_value='station'), \
             patch.object(m, '_enter_station'), patch.object(m, '_finalize_after_station',return_value=True):
            m._complete_workflow(self.driver, 'CHECK', self.cfg, self.target, self.events.append)
        self.driver.get.assert_not_called()

    def test_no_station_omits_enter(self):
        self.cfg['pack_warehouse'] = ''
        self.cfg['pack_station_id'] = ''
        with patch.object(m, '_select_warehouse', side_effect=AssertionError('not needed')), \
             patch.object(m, '_wait_work_page', return_value='station'), \
             patch.object(m, '_enter_station', side_effect=AssertionError('not configured')), \
             patch.object(m, '_finalize_after_station',return_value=True) as fin:
            m._complete_workflow(self.driver, 'PACK', self.cfg, self.cfg['pack_url'], self.events.append)
        self.assertEqual(fin.call_args.kwargs['station_code'], '')

    def test_if_already_scanning_sku_do_not_input_station_code_as_sku(self):
        with patch.object(m, '_wait_work_page', return_value='work'), \
             patch.object(m, '_enter_station',side_effect=AssertionError('wrong field')), \
             patch.object(m, '_finalize_after_station',return_value=True) as fin:
            m._complete_workflow(self.driver, 'CHECK', self.cfg, self.target, self.events.append)
        self.assertEqual(fin.call_args.kwargs['station_code'], '')

    def test_station_confirmation_before_five_second_sleep_and_zoom(self):
        order=[]
        with patch.object(m, '_wait_station_applied',side_effect=lambda *_a, **_kw: order.append('confirmed')), \
             patch.object(m, '_wait_work_page',side_effect=lambda *_a, **_kw: order.append('still-ready') or 'work'), \
             patch.object(m, '_set_browser_zoom',side_effect=lambda *_a, **_kw: order.append('zoom') or True), \
             patch.object(m, '_focus_next_scanner',side_effect=lambda *_a, **_kw: order.append('focus')):
            m._finalize_after_station(self.driver,self.target,self.cfg,station_code='SS00085',
                                      status=lambda _:None,sleep=lambda secs:order.append(('sleep',secs)))
        self.assertEqual(order, ['confirmed',('sleep',5),'still-ready','confirmed','zoom','focus'])

    def test_timeout_never_zooms_if_station_not_confirmed(self):
        with patch.object(m, '_wait_station_applied',side_effect=m.AutomationError('No SKU stage')), \
             patch.object(m, '_set_browser_zoom', side_effect=AssertionError('must not zoom')):
            with self.assertRaisesRegex(m.AutomationError,'No SKU'):
                m._finalize_after_station(self.driver,self.target,self.cfg,station_code='SS00085',
                                          status=lambda _:None,sleep=lambda _:None)


if __name__ == '__main__': unittest.main()
