"""Headless Chrome acceptance test for asynchronous warehouse and station screens.

Synthetic HTML only: no WMS credentials, calls or third-party services.
"""
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.parse import quote
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    import automation as m
    HAS_SELENIUM = True
except ImportError:
    HAS_SELENIUM = False


HTML = r"""<!DOCTYPE html><html><head><meta charset='utf-8'></head><body>
    <aside style='position:absolute;top:100px;left:20px'>
      <button id='warehouse' onclick='document.getElementById("options").style.display="block"'>VN - VNA</button>
      <div id='options' style='display:none'>
        <button id='change-vnn' onclick='choose(this.textContent)'>VN - VNN</button>
      </div>
    </aside>
    <div id='loading' class='loading-overlay' style='display:none;position:absolute;top:180px;left:450px;width:260px;height:100px;background:lightgrey'>Loading...</div>
    <div id='station-page' style='position:absolute;top:220px;left:450px'>
      <h2>Scan/Input Station ID</h2>
      <input id='station' placeholder='Station ID'>
    </div>
    <div id='work-page' style='display:none;position:absolute;top:220px;left:450px'>
      <h2>Scan/Input Picking ID/Device ID/Order No</h2>
      <input id='sku' placeholder='SKU ID'>
    </div>
    <script>
    function choose(name){
        document.querySelector('#warehouse').textContent=name;
        document.querySelector('#options').style.display='none';
        document.querySelector('#station-page').style.display='none';
        document.querySelector('#loading').style.display='block';
        setTimeout(()=>{
            document.querySelector('#loading').style.display='none';
            document.querySelector('#station-page').style.display='block';
        },1400);
    }
    document.querySelector('#station').addEventListener('keydown', (event)=>{
        if(event.key==='Enter'){
            document.querySelector('#station-page').style.display='none';
            document.querySelector('#loading').style.display='block';
            setTimeout(()=>{
                document.querySelector('#loading').style.display='none';
                document.querySelector('#work-page').style.display='block';
            },900);
        }
    });
    </script>
    </body></html>"""


@unittest.skipUnless(HAS_SELENIUM, 'Requires Selenium')
class WarehouseReloadBrowserTests(unittest.TestCase):
    def test_delayed_warehouse_switch_and_station_confirmed_before_zoom(self):
        opts=webdriver.ChromeOptions()
        opts.add_argument('--headless=new')
        opts.add_argument('--no-first-run')
        opts.add_argument('--window-size=1400,900')
        with tempfile.TemporaryDirectory(prefix='wms-v17-test-') as tmp:
            opts.add_argument('--user-data-dir='+tmp)
            browser=webdriver.Chrome(options=opts)
            try:
                browser.get('data:text/html,'+quote(HTML))
                target=browser.current_url
                self.assertEqual(m._current_warehouse_control(browser)[1], 'VN - VNA')
                self.assertTrue(m._select_warehouse(browser,'VN - VNN',lambda _:None,timeout=7))
                with patch.object(m,'_host',return_value=m.WMS_HOST):
                    m._wait_warehouse_reload(browser,'VN - VNN',lambda _:None,timeout=9)
                self.assertEqual(m._wait_work_page(browser,target,warehouse='VN - VNN',timeout=8), 'station')
                m._enter_station(browser,'SS00085',lambda _:None)
                m._wait_station_applied(browser,target,'SS00085',warehouse='VN - VNN',timeout=7)
                events=[]
                with patch.object(m,'_set_browser_zoom',side_effect=lambda *_a,**_kw:events.append('zoom') or True):
                    self.assertTrue(m._finalize_after_station(browser,target,{'chrome_zoom_percent':75},
                                     station_code='SS00085',warehouse='VN - VNN',
                                     status=lambda _:None,sleep=lambda t:events.append(('sleep',t))))
                self.assertEqual(events, [('sleep',5),'zoom'])
                self.assertEqual(browser.switch_to.active_element.get_attribute('id'), 'sku')
            finally:
                browser.quit()

if __name__=='__main__': unittest.main()
