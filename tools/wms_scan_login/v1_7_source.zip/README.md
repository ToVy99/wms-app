# WMS SCAN LOGIN v1.4 — CHECK / PACK

Giao diện mới: hiện đại, sáng, hai vùng quét CHECK (xanh dương) và PACK (tím), thanh trạng thái, Cài đặt chia **Cơ bản/Nâng cao**. Tối ưu cho màn hình máy tính/laptop Windows. Giao diện viết bằng Tkinter, không cần thư viện giao diện bên ngoài.

## Cách dùng
1. Chạy file `WMS_Scan_Login.exe` trên Windows 10/11 có Chrome. Nếu dùng bản mã nguồn, chạy `pip install -r requirements.txt`, rồi `python main.py`.
2. Mở **Cài đặt → Cơ bản**. Nhập mật khẩu dùng chung lần đầu, nhấn **Lưu cài đặt**. Mật khẩu được Windows DPAPI bảo vệ theo tài khoản Windows đang dùng.
3. Đặt **Mã trạm CHECK** mặc định `SS00085`; mã PACK để trống. Có thể sửa bất kỳ lúc nào. Để trống nghĩa là bỏ qua thao tác nhập trạm.
4. Chọn một ô CHECK hoặc PACK, quét mã nhân viên (súng scan cần gửi **Enter**). Hoặc nhập tay và nhấn nút đăng nhập.
5. Tool mở Chrome, đăng nhập vào trang xác thực Shopee/WMS, chuyển đến trang CHECK hoặc PACK tương ứng. Nếu đã có mã trạm đã lưu, tool sẽ thử tự nhập mã rồi gửi Enter trên trang đích.

## Giữ nguyên logic
- CHECK: https://wms.ssc.shopee.vn/v2/salesoutbound/checkingnew
- PACK: https://wms.ssc.shopee.vn/v2/salesoutbound/packing
- Cấu hình lưu tại `%LOCALAPPDATA%\WMS_Scan_Login\settings.json` (nếu bản trước đã có, sẽ dùng lại).
- Mã nguồn **không chứa mật khẩu**. Không gửi hay ghi lại tài khoản quét và mật khẩu.
- Tùy chọn cửa sổ riêng cho CHECK/PACK và giữ tool luôn nổi vẫn hoạt động.
- Việc nhập mã trạm phụ thuộc cấu trúc trang WMS thực tế. Nếu không tìm được vùng nhập, tool vẫn giữ phiên đăng nhập và báo lỗi để nhập thủ công.

## Build EXE
Chạy `BUILD_WINDOWS.bat` trên Windows (có Python) hoặc GitHub Actions. Build với PyInstaller `--onefile --windowed`, dùng `--collect-all` cho Selenium, Trio, WebSocket, urllib3, certifi, sniffio, attrs để tránh thiếu thư viện.

## Kiểm thử
- `python -m unittest discover -s tests -v`
- Trên desktop Windows: `python main.py --ui-smoke` kiểm tra giao diện và hộp thoại.
- Trên Windows có Chrome: `python main.py --self-test` kiểm tra mở Chrome và gửi mã trạm trên trang giả lập. Bài test không đăng nhập WMS thực tế.


## v1.5 – Tự đặt zoom trình duyệt
- Cài đặt → Cơ bản → Zoom trang WMS: 50%, 67%, 75% (mặc định), 80%, 90%, 100%.
- Sau khi WMS mở đúng trang CHECK/PACK, tool đưa Chrome về 100% rồi điều chỉnh zoom bằng Ctrl+Minus đến mức yêu cầu; nếu Chrome không hỗ trợ phím tắt, tự áp dụng CSS zoom làm dự phòng.
- Mã trạm tiếp tục được tự điền và Enter theo cấu hình của từng ô; nếu để trống sẽ bỏ qua.
- Mật khẩu nằm trong Windows DPAPI, tuyệt đối không đưa vào mã nguồn hay lịch sử build.


## WMS Auto Login v1.6 — kho CHECK/PACK và Zoom cuối cùng

- Trong **Cài đặt → Kho làm việc**, chọn kho riêng cho CHECK/PACK (VN - VNA, VN - VNG, VN - VNHN, VN - VNN) hoặc nhập kho hợp lệ khác. Để trống = không đổi kho.
- Chỉ đổi sang kho xuất hiện trên tài khoản WMS. Nếu không tìm thấy hoặc chưa xác nhận chuyển kho, tool không tự quét mã trạm để tránh sai kho.
- Sau khi nhập mã trạm + Enter (nếu có), đợi đủ **5 giây**, cuối cùng Zoom Chrome tới tỷ lệ đã lưu, mặc định 75%.
- Nếu không có mã trạm, tool đợi 5 giây sau khi trang đã sẵn sàng rồi Zoom.
- Đã giữ nguyên đăng nhập, mã trạm mặc định CHECK=SS00085, PACK=trống và mật khẩu mã hóa bằng Windows DPAPI.

## v1.7 – chờ kho và màn hình quét trước khi zoom

- Nếu kho CHECK/PACK để trống: giữ kho hiện tại, không chuyển kho hoặc tải lại vì lý do chọn kho.
- Nếu có kho: chờ tên kho ổn định sau tải lại, mở lại trang làm việc và chờ chính xác ô quét xuất hiện.
- Chỉ nhập mã trạm + Enter khi màn hình `Scan/Input Station ID` ổn định. Sau khi Enter, đợi WMS chuyển sang màn hình quét tiếp theo (Picking/Order/SKU), tránh nhận nhầm `station` đã được xử lý khi trang vẫn đang tải.
- Chờ thêm 5 giây rồi kiểm tra trang một lần nữa, Zoom theo cài đặt (mặc định 75%) và đưa focus về ô quét thích hợp. Trường hợp không cài mã trạm cũng đợi trang sẵn sàng rồi mới đếm 5 giây.
- Nếu hết 60 giây không nhận được trạng thái hợp lệ, công cụ báo rõ lỗi và giữ Chrome mở để thao tác thủ công, không nhập nhầm mã hoặc zoom trong lúc tải lại.
- Kiểm thử trên HTML giả lập, không sử dụng tài khoản WMS thực tế. Phần trang WMS thật phụ thuộc giao diện của Shopee.
