"""Selenium flow: scan -> Shopee WFM login -> CHECK/PACK tab.

Never bypasses account protection (OTP / CAPTCHA / SSO).  Password is not
included in this source and is decrypted locally with Windows DPAPI.
"""
from __future__ import annotations

import re
import time
import shutil
import tempfile
from pathlib import Path
from typing import Callable
from urllib.parse import urlparse

from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait

from settings import decrypt_password, validate_station_id, validate_zoom, validate_warehouse

AUTH_HOST = "wfm.business.accounts.shopee.com"
WMS_HOST = "wms.ssc.shopee.vn"


class AutomationError(Exception):
    """An error message suitable for display to an operator."""


def _visible(elements):
    for element in elements:
        try:
            if element.is_displayed() and element.is_enabled():
                yield element
        except WebDriverException:
            continue


def _lookup(driver, css):
    if not css:
        return None
    return next(_visible(driver.find_elements(By.CSS_SELECTOR, css)), None)


def _detect_username(driver, custom_css=""):
    if custom_css:
        return _lookup(driver, custom_css)
    # WFM screenshot: placeholder="User ID".  Other selectors act as fallback.
    for css in (
        "input[placeholder*='User ID' i]",
        "input[placeholder*='Username' i]",
        "input[name='username']",
        "input[name='userId']",
        "input[autocomplete='username']",
        "input[id*='user' i]",
    ):
        match = _lookup(driver, css)
        if match is not None:
            return match
    candidates = list(_visible(driver.find_elements(By.CSS_SELECTOR, "input:not([type='password'])")))
    text_candidates = []
    for element in candidates:
        eltype = (element.get_attribute("type") or "text").lower()
        if eltype not in ("text", "email", "tel", "number", "search", ""):
            continue
        desc = " ".join((element.get_attribute(a) or "") for a in
                        ("name", "id", "placeholder", "aria-label", "autocomplete")).lower()
        if re.search(r"user|account|login|email|employee|staff|tài khoản|nhân viên|đăng nhập|用户名|账号", desc):
            return element
        text_candidates.append(element)
    return text_candidates[0] if len(text_candidates) == 1 else None


def _detect_password(driver, custom_css=""):
    return _lookup(driver, custom_css or "input[type='password']")


def _detect_submit(driver, custom_css=""):
    if custom_css:
        return _lookup(driver, custom_css)
    elements = list(_visible(driver.find_elements(By.CSS_SELECTOR, "button, input[type='submit'], [role='button']")))
    for element in elements:
        label = " ".join(filter(None, (element.text, element.get_attribute("value") or "",
                                       element.get_attribute("aria-label") or "")))
        if re.search(r"\blog\s*in\b|\bsign\s*in\b|đăng nhập|登录|登入", label, re.I):
            return element
    for element in elements:
        if (element.get_attribute("type") or "").lower() == "submit":
            return element
    return None


def _host(url):
    return (urlparse(url).hostname or "").lower()


def _auth_visible(driver, cfg):
    return _detect_password(driver, cfg.get("password_css", "")) is not None


def _login_loaded(driver, cfg):
    # Selenium follows the WMS -> WFM redirect. Do NOT treat the initial WMS
    # URL as proof that login has succeeded before the redirect completes.
    return _detect_username(driver, cfg.get("username_css", "")) is not None and \
        _detect_password(driver, cfg.get("password_css", "")) is not None


def _signed_in(driver, cfg):
    return _host(driver.current_url) == WMS_HOST and not _auth_visible(driver, cfg) and \
        driver.execute_script("return document.readyState") in ("interactive", "complete")


def _send_text(element, text):
    element.click()
    element.clear()
    element.send_keys(text)


def _explain_login_failure(driver, cfg):
    host = _host(driver.current_url)
    if host == AUTH_HOST or _auth_visible(driver, cfg):
        return ("Trang WFM vẫn đang hiển thị đăng nhập. Kiểm tra User ID/mật khẩu, "
                "thông báo lỗi hoặc bước xác thực trên Chrome.")
    return ("Không nhận được xác nhận đăng nhập từ WMS. "
            "Kiểm tra Chrome và kết nối mạng.")



def _station_field(driver):
    """Only target a clearly identified station field, never arbitrary WMS inputs."""
    for css in (
        "input[placeholder*='station' i]",
        "input[aria-label*='station' i]",
        "input[name*='station' i]",
        "input[id*='station' i]",
        "textarea[placeholder*='station' i]",
        "[contenteditable='true'][aria-label*='station' i]",
    ):
        result = _lookup(driver, css)
        if result is not None:
            return result
    return None


def _station_prompt(driver):
    """Find the scanner target shown as 'Scan/Input Station ID' on CHECK."""
    try:
        matches = driver.find_elements(By.XPATH,
            "//*[contains(translate(normalize-space(text()), "
            "'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), "
            "'scan/input station id')]")
        return next(_visible(matches), None)
    except WebDriverException:
        return None


def _enter_station(driver, station_code: str, status: Callable[[str], None]):
    """Send station code and Enter, using either field or WMS scanner prompt.

    WMS may implement its scanner as a keyboard listener rather than an input.
    In that case click the specific scanner prompt before typing.
    """
    station_code = validate_station_id(station_code)
    if not station_code:
        return
    status(f"Mở trang thành công. Chờ ô nhập mã trạm {station_code}...")
    try:
        WebDriverWait(driver, 24, poll_frequency=0.4).until(
            lambda d: _station_field(d) or _station_prompt(d)
        )
    except TimeoutException as exc:
        raise AutomationError("Không tìm thấy ô Scan/Input Station ID trên trang WMS.") from exc

    field = _station_field(driver)
    if field is None:
        prompt = _station_prompt(driver)
        if prompt is None:
            raise AutomationError("Không nhận diện được vị trí nhập mã trạm.")
        try:
            prompt.click()
        except WebDriverException as exc:
            raise AutomationError("Không chọn được vị trí Scan/Input Station ID.") from exc
        # Some WMS screens reveal a station input after clicking the prompt.
        try:
            field = WebDriverWait(driver, 3, poll_frequency=0.25).until(
                lambda d: _station_field(d)
            )
        except TimeoutException:
            field = None

    if field is not None:
        _send_text(field, station_code)
        field.send_keys(Keys.ENTER)
    else:
        # The dedicated scanner prompt uses global keyboard events.
        ActionChains(driver).send_keys(station_code).send_keys(Keys.ENTER).perform()
    status(f"Đã gửi mã trạm {station_code} + Enter; WMS sẽ xử lý mã trạm.")


# Number of Ctrl+Minus presses from Chrome's default 100% zoom.
# Chrome's steps: 100 -> 90 -> 80 -> 75 -> 67 -> 50.
CHROME_ZOOM_DECREMENTS = {100: 0, 90: 1, 80: 2, 75: 3, 67: 4, 50: 5}


def _set_browser_zoom(driver, value: int, status: Callable[[str], None]):
    """Zoom the active Chrome destination tab, not the Windows display.

    Reset to 100% first, then use Chrome's native Ctrl+Minus shortcut.
    If Chrome blocks those shortcuts (e.g. in headless drivers), apply an
    HTML root CSS zoom as a safe fallback, without failing a WMS login.
    """
    value = validate_zoom(value)
    status(f"Điều chỉnh hiển thị trang WMS về {value}%...")
    fallback_used = False
    try:
        driver.execute_script("document.documentElement.style.zoom = ''; ")
        ActionChains(driver).key_down(Keys.CONTROL).send_keys("0").key_up(Keys.CONTROL).perform()
        time.sleep(0.12)
        baseline = float(driver.execute_script("return window.devicePixelRatio") or 1)
        for _ in range(CHROME_ZOOM_DECREMENTS[value]):
            ActionChains(driver).key_down(Keys.CONTROL).send_keys("-").key_up(Keys.CONTROL).perform()
            time.sleep(0.12)
        time.sleep(0.15)
        actual = float(driver.execute_script("return window.devicePixelRatio") or 1)
        # Device pixel ratio reflects native Chrome zoom even on high DPI screens.
        # Avoid applying CSS zoom on top of partially-applied native zoom.
        if abs(actual / baseline - value / 100) > 0.055:
            ActionChains(driver).key_down(Keys.CONTROL).send_keys("0").key_up(Keys.CONTROL).perform()
            time.sleep(0.12)
            driver.execute_script("document.documentElement.style.zoom = arguments[0];", f"{value}%")
            fallback_used = True
    except WebDriverException:
        try:
            ActionChains(driver).key_down(Keys.CONTROL).send_keys("0").key_up(Keys.CONTROL).perform()
            driver.execute_script("document.documentElement.style.zoom = arguments[0];", f"{value}%")
            fallback_used = True
        except WebDriverException:
            status("Không thể điều chỉnh zoom, Chrome giữ tỷ lệ hiện tại.")
            return False
    status(f"Đã đặt trang WMS ở {value}%" + (" (chế độ tương thích)" if fallback_used else ""))
    return True



class WarehouseNotFound(AutomationError):
    """WMS has not displayed its warehouse selector yet."""


def _warehouse_identity(text):
    """Canonical ID used for exact option comparison (not substring matching)."""
    try:
        return validate_warehouse(text)
    except ValueError:
        return ""


def _warehouse_candidates(driver):
    """Enumerate only visible short-label warehouse controls/options.

    Ignore arbitrary WMS content (orders, SKUs, station and login fields).
    Clicking is restricted to the top-left navigation control or a visible
    matching dropdown option AFTER that control has been opened.
    """
    # One browser-side query instead of scanning every DOM node via RPC.
    elements = driver.execute_script(r"""
      const all = document.querySelectorAll('button, span, div, li, a, [role=option]');
      const pattern = /^VN\s*-\s*[A-Z0-9]{2,12}$/i;
      return [...all].filter(el => el.getClientRects().length &&
        pattern.test((el.textContent || '').replace(/\s+/g,' ').trim())).slice(0, 80);
    """)
    seen = set()
    for element in elements:
        try:
            if not element.is_displayed() or not element.is_enabled():
                continue
            raw = (element.get_attribute("textContent") or "").strip()
            name = _warehouse_identity(raw)
            if not name:
                continue
            key = element.id
            if key in seen:
                continue
            seen.add(key)
            yield element, name
        except WebDriverException:
            continue


def _current_warehouse_control(driver):
    """Identify top-left WMS sidebar dropdown by label and screen position."""
    candidates = []
    for el, name in _warehouse_candidates(driver):
        try:
            box = el.rect
            x, y = float(box.get("x", 1e9)), float(box.get("y", 1e9))
            if 0 <= x <= 390 and 45 <= y <= 470:
                candidates.append((y, x, float(box.get("width", 9999)), el, name))
        except WebDriverException:
            pass
    if not candidates:
        return None
    # The sidebar warehouse label appears above the list of warehouses.
    candidates.sort(key=lambda item: (item[0], item[1], item[2]))
    return candidates[0][-2:]


def _select_warehouse(driver, value, status, timeout=20):
    """Switch to configured warehouse; never silently continue in a wrong one.

    Returns True if changed, False if already selected. Raises a specific
    error if requested warehouse is unavailable or access is denied.
    """
    requested = validate_warehouse(value)
    if not requested:
        return False
    status(f"Đang kiểm tra kho {requested}...")
    try:
        current, current_name = WebDriverWait(driver, timeout, poll_frequency=0.5).until(
            lambda d: _current_warehouse_control(d)
        )
    except TimeoutException as exc:
        raise WarehouseNotFound("Chưa xuất hiện bộ chọn kho ở góc trái WMS.") from exc
    if current_name == requested:
        status(f"Kho hiện tại đã đúng: {requested}.")
        return False

    # WMS versions may place the click listener on the text, its parent or a
    # parent button. Try those containers before giving up.
    trigger_candidates = [current]
    try:
        trigger_candidates.extend(current.find_elements(By.XPATH, "./ancestor::*[position() <= 3]"))
    except WebDriverException:
        pass
    selected = None
    for trigger in trigger_candidates:
        try:
            trigger.click()
        except WebDriverException:
            continue
        try:
            selected = WebDriverWait(driver, 3, poll_frequency=0.25).until(
                lambda d: next((el for el, name in _warehouse_candidates(d)
                                if name == requested and el.rect.get("y", 0) >= 0
                                and el.id != current.id), None)
            )
            if selected is not None:
                break
        except TimeoutException:
            pass
    if selected is None:
        raise AutomationError(
            f"Không tìm thấy kho {requested} trong danh sách của tài khoản. "
            "Hãy kiểm tra tên kho và quyền truy cập WMS."
        )
    try:
        selected.click()
    except WebDriverException as exc:
        raise AutomationError(f"Không chọn được kho {requested} trên WMS.") from exc
    # React may reload/replace the sidebar after a warehouse switch.
    try:
        WebDriverWait(driver, 24, poll_frequency=0.5).until(
            lambda d: (_current_warehouse_control(d) or (None, None))[1] == requested
        )
    except TimeoutException as exc:
        raise AutomationError(
            f"Đã chọn {requested}, nhưng WMS chưa xác nhận chuyển kho. "
            "Tool không tự tiếp tục để tránh làm việc nhầm kho."
        ) from exc
    status(f"Đã chuyển kho sang {requested}.")
    return True



# Page readiness is based on the actual WMS scanner UI, not just a URL
# redirect or document.readyState. The React SPA can redraw after a warehouse
# change even when the selected warehouse label already shows its new value.
WORK_READINESS_TIMEOUT = 60
_STABILITY_SECONDS = 1.6


def _browser_document_ready(driver):
    try:
        return driver.execute_script("return document.readyState") == "complete"
    except WebDriverException:
        return False


def _work_prompt(driver):
    """Visible non-station scanner banner (SKU, picking, order, parcel, etc.)."""
    try:
        matches = driver.find_elements(By.XPATH,
            "//*[contains(translate(normalize-space(text()), "
            "'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'scan/input') "
            "and not(contains(translate(normalize-space(text()), "
            "'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'station id'))]")
        return next(_visible(matches), None)
    except WebDriverException:
        return None


def _work_field(driver):
    """Never focus a generic input or a navigation/search field."""
    for css in (
        "input[placeholder*='sku' i]", "input[aria-label*='sku' i]",
        "input[placeholder*='picking' i]", "input[aria-label*='picking' i]",
        "input[placeholder*='order no' i]", "input[aria-label*='order no' i]",
        "input[placeholder*='device id' i]", "input[aria-label*='device id' i]",
        "input[placeholder*='parcel' i]", "input[aria-label*='parcel' i]",
    ):
        field = _lookup(driver, css)
        if field is not None:
            return field
    return None


def _scan_screen(driver):
    # Explicit station prompt takes priority, until WMS confirms a different
    # operation prompt. A checked station may instead resume on a work screen.
    if _station_field(driver) or _station_prompt(driver):
        return 'station'
    if _work_field(driver) or _work_prompt(driver):
        return 'work'
    return ''


def _ui_loading(driver):
    try:
        return bool(driver.execute_script(r"""
            const sel = '.ant-spin-spinning, .el-loading-mask, .v-loading-mask, '
                      + '[aria-busy="true"], .loading-overlay';
            return [...document.querySelectorAll(sel)].some(el => {
                const r = el.getBoundingClientRect();
                const st = window.getComputedStyle(el);
                return r.width > 10 && r.height > 10 && st.display !== 'none' &&
                       st.visibility !== 'hidden';
            });
        """))
    except WebDriverException:
        return True


def _wait_stable(driver, probe, *, timeout=WORK_READINESS_TIMEOUT,
                 stable_for=_STABILITY_SECONDS, error='WMS chưa sẵn sàng'):
    """Require a consistent success state over multiple polls, not 1 snapshot.

    A warehouse dropdown can update before React has finished replacing its
    work page; this guard prevents entering codes into the disappearing DOM.
    """
    since = None
    last_identity = None
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            identity = probe(driver)
        except WebDriverException:
            identity = None
        now = time.monotonic()
        if identity:
            if identity != last_identity:
                last_identity, since = identity, now
            elif since is not None and now - since >= stable_for:
                return identity
        else:
            since = None
            last_identity = None
        time.sleep(.3)
    raise AutomationError(error + f' (quá {int(timeout)} giây).')


def _wait_warehouse_reload(driver, warehouse, status, timeout=WORK_READINESS_TIMEOUT):
    """After switching, wait for a stable loaded WMS page before navigating."""
    status(f'Đang chờ WMS tải lại sau khi chuyển kho {warehouse}...')
    expected = validate_warehouse(warehouse)

    def check(d):
        if _host(d.current_url) != WMS_HOST or not _browser_document_ready(d) or _ui_loading(d):
            return None
        current = _current_warehouse_control(d)
        return expected if current and current[1] == expected else None

    return _wait_stable(driver, check, timeout=timeout, stable_for=2.0,
                        error=f'WMS chưa hoàn tất chuyển sang {expected}')


def _wait_work_page(driver, target, *, warehouse='', timeout=WORK_READINESS_TIMEOUT,
                    status=lambda _: None):
    """Wait for scanner UI and an optional verified warehouse on target route."""
    status('Đang chờ trang CHECK/PACK tải xong và xuất hiện ô quét...')
    expected_route = target.split('?', 1)[0].rstrip('/')
    expected_wh = validate_warehouse(warehouse)

    def check(d):
        if d.current_url.split('?', 1)[0].rstrip('/') != expected_route:
            return None
        if not _browser_document_ready(d) or _ui_loading(d):
            return None
        if expected_wh:
            current = _current_warehouse_control(d)
            if not current or current[1] != expected_wh:
                return None
        stage = _scan_screen(d)
        return (stage, expected_wh) if stage else None

    return _wait_stable(driver, check, timeout=timeout,
                        error='Trang CHECK/PACK chưa hiển thị ô quét sau khi tải lại')[0]


def _wait_station_applied(driver, target, station, *, warehouse='',
                          timeout=WORK_READINESS_TIMEOUT, status=lambda _: None):
    """Require WMS's NEXT scanner screen after station + Enter.

    CHECK can show Picking/Order first, then SKU; requiring SKU alone would
    block legitimate flows waiting for an order/picking barcode.
    """
    status(f'Đã gửi {station} + Enter. Chờ WMS xác nhận chuyển sang màn hình quét...')
    expected_route = target.split('?', 1)[0].rstrip('/')
    expected_wh = validate_warehouse(warehouse)

    def check(d):
        if d.current_url.split('?', 1)[0].rstrip('/') != expected_route:
            return None
        if not _browser_document_ready(d) or _ui_loading(d):
            return None
        if expected_wh:
            current = _current_warehouse_control(d)
            if not current or current[1] != expected_wh:
                return None
        # A station field that persists implies WMS has not accepted it.
        return 'work' if _scan_screen(d) == 'work' else None

    return _wait_stable(driver, check, timeout=timeout,
                        error=f'WMS chưa xác nhận mã trạm {station} hoặc vẫn đang tải')


def _focus_next_scanner(driver, status):
    """Restore work barcode focus after native Ctrl+- changes keyboard focus."""
    try:
        target = _work_field(driver)
        if target is None and _scan_screen(driver) == 'work':
            target = _work_prompt(driver)
        if target is None and _scan_screen(driver) == 'station':
            target = _station_field(driver) or _station_prompt(driver)
        if target is not None:
            target.click()
            status('Đã đưa con trỏ về vị trí quét. Sẵn sàng làm việc.')
            return True
    except WebDriverException:
        pass
    status('Đã hoàn tất Zoom; cần bấm vào ô quét trên WMS nếu con trỏ chưa đúng.')
    return False


def _finalize_after_station(driver, target, cfg, *, station_code='', warehouse='',
                            status=lambda _: None, sleep=time.sleep):
    """Post-station state machine; zoom only once WMS is confirmed ready."""
    if station_code:
        _wait_station_applied(driver, target, station_code,
                              warehouse=warehouse, status=status)
    else:
        status('Không cài mã trạm; trang WMS đã sẵn sàng.')
    status('Chờ 5 giây sau khi trang sẵn sàng rồi thu phóng...')
    sleep(5)
    # Check again: dynamic WMS may reload even during the 5-second pause.
    _wait_work_page(driver, target, warehouse=warehouse, status=status)
    if station_code:
        # If WMS reverted to Station ID while waiting, refuse to zoom into
        # an intermediate state and keep the browser for manual recovery.
        _wait_station_applied(driver, target, station_code,
                              warehouse=warehouse, status=status)
    zoom_percent = cfg.get('chrome_zoom_percent', 75)
    zoomed = _set_browser_zoom(driver, zoom_percent, status)
    _focus_next_scanner(driver, status)
    return zoomed

def _complete_workflow(driver, lane, cfg, target, status):
    """Post-login WMS flow, separate from authentication for reliable testing."""
    warehouse = validate_warehouse(cfg.get(
        'check_warehouse' if lane == 'CHECK' else 'pack_warehouse', ''))
    # Warehouse selection is optional. Do NOT force another reload
    # when the operator intentionally left CHECK/PACK warehouse blank.
    if warehouse:
        status(f"{lane}: [2/6] Kiểm tra/chuyển kho {warehouse}...")
        switched = _select_warehouse(driver, warehouse,
                                     lambda msg: status(f"{lane}: {msg}"), timeout=25)
        if switched:
            # Do not navigate immediately after the dropdown changes:
            # the WMS SPA may still be writing/reloading its warehouse.
            _wait_warehouse_reload(driver, warehouse,
                                   lambda msg: status(f"{lane}: {msg}"))
            status(f"{lane}: [3/6] Mở lại trang làm việc ở đúng kho...")
            driver.get(target)
    else:
        status(f"{lane}: [2/6] Không chọn kho, giữ nguyên kho WMS.")

    status(f"{lane}: [3/6] Đợi giao diện nhập trạm sẵn sàng...")
    stage = _wait_work_page(driver, target, warehouse=warehouse,
                            status=lambda msg: status(f"{lane}: {msg}"))
    station_code = validate_station_id(
        cfg.get("check_station_id" if lane == "CHECK" else "pack_station_id", ""))
    if station_code:
        if stage == 'station':
            status(f"{lane}: [4/6] Nhập trạm {station_code} và Enter...")
            _enter_station(driver, station_code,
                           lambda msg: status(f"{lane}: {msg}"))
        else:
            # On a restored session the scanner could already be on
            # Picking/SKU. Never type the station ID as an SKU/order.
            status(f"{lane}: [4/6] Trang đã ở bước quét hàng; không bắn mã trạm vào ô SKU.")
            station_code = ''
    else:
        status(f"{lane}: [4/6] Không cài mã trạm, bỏ qua.")
    status(f"{lane}: [5/6] Xác nhận trang sẵn sàng và chờ 5 giây...")
    zoomed = _finalize_after_station(
        driver, target, cfg, station_code=station_code, warehouse=warehouse,
        status=lambda msg: status(f"{lane}: {msg}"))
    status(f"{lane}: [6/6] Hoàn tất · " +
           (f"Kho {warehouse}" if warehouse else "Giữ kho hiện tại") +
           (f" · Zoom {cfg.get('chrome_zoom_percent',75)}%." if zoomed else
            " · Zoom chưa thay đổi."))

class SessionManager:
    """Separate, isolated Chrome window/profile for each CHECK/PACK scan."""

    def __init__(self):
        self.sessions = {}  # CHECK/PACK -> (WebDriver, temporary profile directory)

    def _close(self, lane):
        old = self.sessions.pop(lane, None)
        if old:
            driver, profile = old
            try:
                driver.quit()
            except Exception:
                pass
            shutil.rmtree(profile, ignore_errors=True)

    def close_all(self):
        for lane in list(self.sessions):
            self._close(lane)

    def login(self, lane: str, username: str, cfg: dict, status: Callable[[str], None]):
        if lane not in ("CHECK", "PACK"):
            raise AutomationError("Vị trí không hợp lệ.")
        username = username.strip()
        if not username:
            raise AutomationError("Mã tài khoản trống.")
        try:
            password = decrypt_password(cfg.get("encrypted_password", ""))
        except Exception as exc:
            raise AutomationError("Không giải mã được mật khẩu đã lưu. Mở Cài đặt và nhập lại mật khẩu.") from exc
        if not password:
            raise AutomationError("Chưa lưu mật khẩu. Vào Cài đặt để nhập mật khẩu chung.")

        target = cfg["check_url"] if lane == "CHECK" else cfg["pack_url"]
        if not cfg.get("open_separate_windows", True):
            self.close_all()
        else:
            self._close(lane)
        profile = Path(tempfile.mkdtemp(prefix="wms_scan_"))
        options = webdriver.ChromeOptions()
        options.add_argument(f"--user-data-dir={profile}")
        options.add_argument("--start-maximized")
        options.add_argument("--no-first-run")
        options.add_argument("--no-default-browser-check")
        try:
            status(f"{lane}: Mở Chrome...")
            driver = webdriver.Chrome(options=options)
        except Exception as exc:
            shutil.rmtree(profile, ignore_errors=True)
            raise AutomationError("Không mở được Chrome. Kiểm tra Chrome đã cài và kết nối mạng.") from exc
        self.sessions[lane] = (driver, profile)
        try:
            status(f"{lane}: Mở trang WMS và chờ chuyển tới Shopee WFM...")
            driver.get(cfg["login_url"])
            try:
                WebDriverWait(driver, 50, poll_frequency=0.35).until(lambda d: _login_loaded(d, cfg))
            except TimeoutException as exc:
                raise AutomationError(
                    "Không thấy ô User ID/Password trên trang đăng nhập WFM sau 50 giây. "
                    "Kiểm tra trang đang mở trên Chrome."
                ) from exc

            username_input = _detect_username(driver, cfg.get("username_css", ""))
            password_input = _detect_password(driver, cfg.get("password_css", ""))
            if username_input is None or password_input is None:
                raise AutomationError("Không nhận diện được User ID hoặc Password trên WFM.")

            status(f"{lane}: Điền tài khoản và mật khẩu...")
            _send_text(username_input, username)
            _send_text(password_input, password)
            submit = _detect_submit(driver, cfg.get("submit_css", ""))
            if submit is None:
                password_input.send_keys(Keys.ENTER)
            else:
                WebDriverWait(driver, 12).until(lambda d: submit.is_enabled())
                submit.click()

            status(f"{lane}: Đã bấm Log In. Đang xác nhận phiên đăng nhập...")
            try:
                WebDriverWait(driver, 65, poll_frequency=0.5).until(lambda d: _signed_in(d, cfg))
            except TimeoutException as exc:
                raise AutomationError(_explain_login_failure(driver, cfg)) from exc

            # Open the target page first: callback/landing routes often have
            # no warehouse sidebar. Avoid wasting 9 seconds on every login.

            # A new destination TAB appears after login. Close the old login
            # tab only after the target is confirmed, so operators see one
            # useful working tab rather than a stale authentication page.
            login_tab = driver.current_window_handle
            status(f"{lane}: Đã đăng nhập. Mở tab {lane}...")
            driver.switch_to.new_window("tab")
            driver.get(target)
            try:
                WebDriverWait(driver, 40, poll_frequency=0.5).until(
                    lambda d: d.current_url.split("?", 1)[0].rstrip("/") == target.split("?", 1)[0].rstrip("/")
                    and not _auth_visible(d, cfg)
                )
            except TimeoutException as exc:
                raise AutomationError(
                    "Đã đăng nhập nhưng không thể mở trang " + lane +
                    ". Kiểm tra quyền truy cập/kho đang chọn trên WMS."
                ) from exc
            # A login tab can usually be closed after the target tab is ready.
            try:
                new_tab = driver.current_window_handle
                driver.switch_to.window(login_tab)
                driver.close()
                driver.switch_to.window(new_tab)
            except WebDriverException:
                pass
            _complete_workflow(driver, lane, cfg, target, status)
        except AutomationError:
            raise
        except WebDriverException as exc:
            raise AutomationError(
                f"Chrome/Selenium: {exc.__class__.__name__}. "
                "Xem log lỗi để biết chi tiết."
            ) from exc
